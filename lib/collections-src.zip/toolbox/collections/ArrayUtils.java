package toolbox.collections;

import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Comparator;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;


/**
 * Utilities to handle array.
 * 
 * @author river, David
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ArrayUtils {
    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param o
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] push(T[] arr, T o) {
        T[] newArr = (T[]) Array.newInstance(o.getClass(),
                arr.length + 1);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = o;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static String[] push(String[] arr, String i) {
        String[] newArr = new String[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static int[] push(int[] arr, int i) {
        int[] newArr = new int[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static byte[] push(byte[] arr, byte i) {
        byte[] newArr = new byte[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static boolean[] push(boolean[] arr, boolean i) {
        boolean[] newArr = new boolean[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static char[] push(char[] arr, char i) {
        char[] newArr = new char[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static short[] push(short[] arr, short i) {
        short[] newArr = new short[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param i
     * @return new array
     */
    public final static long[] push(long[] arr, long i) {
        long[] newArr = new long[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = i;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param f
     * @return new array
     */
    public final static float[] push(float[] arr, float f) {
        float[] newArr = new float[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = f;
        return newArr;
    }

    /**
     * Add one element to the end of array.
     * 
     * @param arr
     * @param f
     * @return new array
     */
    public final static double[] push(double[] arr, double f) {
        double[] newArr = new double[arr.length + 1];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        newArr[arr.length] = f;
        return newArr;
    }
    
    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param type
     * @param size
     * @return new array
     */
    public final static Object[] expand(Object[] arr, Class<?> type, int size) {
        if (size <= arr.length) {
            return arr;
        }
        Object[] newArr = (Object[]) Array.newInstance(type, size);
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }
    
    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static String[] expand(String[] arr, int size) {
        if (size <= arr.length)
            return arr;
        String[] newArr = new String[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static int[] expand(int[] arr, int size) {
        if (size <= arr.length)
            return arr;
        int[] newArr = new int[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static boolean[] expand(boolean[] arr, int size) {
        if (size <= arr.length)
            return arr;
        boolean[] newArr = new boolean[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static char[] expand(char[] arr, int size) {
        if (size <= arr.length)
            return arr;
        char[] newArr = new char[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static long[] expand(long[] arr, int size) {
        if (size <= arr.length)
            return arr;
        long [] newArr = new long[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static byte[] expand(byte[] arr, int size) {
        if (size <= arr.length)
            return arr;
        byte[] newArr = new byte[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static short[] expand(short [] arr, int size) {
        if (size <= arr.length)
            return arr;
        short [] newArr = new short[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static float[] expand(float[] arr, int size) {
        if (size <= arr.length)
            return arr;
        float[] newArr = new float[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;        
    }

    /**
     * Expand the array to specified size.
     * 
     * @param arr
     * @param size
     * @return new array
     */
    public final static double[] expand(double[] arr, int size) {
        if (size <= arr.length)
            return arr;
        double[] newArr = new double[size];
        System.arraycopy(arr, 0, newArr, 0, arr.length);
        return newArr;        
    }
    
    /**
     * Extract a sub list from an array by a mask.
     * 
     * @param <T>  the type of the component of the array
     * @param src  the source array.
     * @param mask  the mask array. Only the components in src whose corresponding components in
     *              mask values true will be extracted to the results
     * @return  the extracted sub-list
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] extract(T[] src, boolean[] mask) {
        if (src == null) {
            return null;
        }
        // count
        int count = 0;
        for (int i = 0; i < mask.length; i++) {
            if (mask[i]) {
                count++;
            }
        }
        // new
        T[] res = (T[]) Array.newInstance(src.getClass().getComponentType(),
                count);
        // copy
        int j = 0;
        for (int i = 0; i < mask.length; i++) {
            if (mask[i]) {
                res[j++] = src[i];
            }
        }
        // return
        return res;
    }

    /**
     * Remove the first element of array.
     * 
     * @param arr
     * @return new array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] shift(T [] arr) {
        assert arr.length > 0;
        T [] newArr = (T[]) Array.newInstance(arr.getClass().getComponentType(),
                arr.length - 1);
        System.arraycopy(arr, 1, newArr, 0, arr.length - 1);
        return newArr;
    }
    
    /**
     * Sort arrays.
     * The input is a series of arrays. All the arrays will be sorted according 
     * to the first array's elements.
     * 
     * Usage:
     *   int[] keys = new int[]{1, 5, 4};
     *   int[] vals = new String[]{"A", "B", "C"};
     *   sortArrays(kyes, vals);
     * the sorted results are:
     *   keys: {1, 4, 5}
     *   vals: {"A", "C", "B"}
     *   
     * @param arrays  the arrays to be sorted
     */
    public static void sortArrays(Object... arrays) {
        int arrayCount = arrays.length;
        int len = Array.getLength(arrays[0]);

        Object[][] wrappers = new Object[len][arrayCount];
        for (int i = 0; i < len; i++) {
            for (int j = 0; j < arrayCount; j++) {
                wrappers[i][j] = Array.get(arrays[j], i);
            }
        }

        Arrays.sort(wrappers, new Comparator<Object[]>() {

            @SuppressWarnings({
                "unchecked", "rawtypes"
            })
            @Override
            public int compare(Object[] o1, Object[] o2) {
                return ((Comparable) o1[0]).compareTo(o2[0]);
            }
        });

        for (int i = 0; i < len; i++) {
            for (int j = 0; j < arrayCount; j++) {
                Array.set(arrays[j], i, wrappers[i][j]);
            }
        }
    }

    /**
     * Extract a contineous sub array.  The result is a new instance of array, 
     * and values are copied by calling System.arraycopy.
     * If the param <code>"len"</code> is larger than the actural element count
     * in the source array from start, all the elements from start should be 
     * copied to the returned array.
     * 
     * @param <T>  The type of the array.
     * @param arr  the source array
     * @param start  the start index of the sub array
     * @param len  the length of the sub array
     * @return  the copied sub array
     */
    @SuppressWarnings("unchecked")
    public static <T> T[] subArray(T[] arr, int start, int len) {
        if (len > arr.length - start) len = arr.length - start;
        T [] newArr = (T[]) Array.newInstance(arr.getClass().getComponentType(), 
                len);
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static int[] subArray(int[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        int[] newArr = new int[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static long[] subArray(long[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        long[] newArr = new long[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static byte[] subArray(byte[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        byte[] newArr = new byte[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static char[] subArray(char[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        char[] newArr = new char[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static short[] subArray(short[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        short[] newArr = new short[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static float[] subArray(float[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        float[] newArr = new float[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static double[] subArray(double[] arr, int start, int len) {
        if (len > arr.length - start)
            len = arr.length - start;
        double[] newArr = new double[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }

    /**
     * Primitive implementation of {@link #subArray(Object[], int, int)}.
     * 
     * @param arr
     * @param start
     * @param len
     * @return
     */
    public static boolean[] subArray(boolean[] arr, int start, int len) {
        if (len > arr.length - start) {
            len = arr.length - start;
        }
        boolean[] newArr = new boolean[len];
        System.arraycopy(arr, start, newArr, 0, len);
        return newArr;
    }
    
    /**
     * Tuning parameter: list size at or below which insertion sort will be
     * used in preference to mergesort or quicksort.
     */
    private static final int INSERTIONSORT_THRESHOLD = 7;
    
    /**
     * Check that fromIndex and toIndex are in range, and throw an
     * appropriate exception if they aren't.
     */
    private static void rangeCheck(int arrayLen, int fromIndex, int toIndex) {
        if (fromIndex > toIndex)
            throw new IllegalArgumentException("fromIndex(" + fromIndex +
                       ") > toIndex(" + toIndex+")");
        if (fromIndex < 0)
            throw new ArrayIndexOutOfBoundsException(fromIndex);
        if (toIndex > arrayLen)
            throw new ArrayIndexOutOfBoundsException(toIndex);
    }

    /**
     * The comparator for two integers.
     * 
     * @author david
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public static interface IIntComparator {
        /**
         * Compares its two arguments for order.  Returns a negative integer,
         * zero, or a positive integer as the first argument is less than, equal
         * to, or greater than the second.<p>
         *
         * The implementor must ensure that <tt>sgn(compare(x, y)) ==
         * -sgn(compare(y, x))</tt> for all <tt>x</tt> and <tt>y</tt>.  (This
         * implies that <tt>compare(x, y)</tt> must throw an exception if and only
         * if <tt>compare(y, x)</tt> throws an exception.)<p>
         *
         * The implementor must also ensure that the relation is transitive:
         * <tt>((compare(x, y)&gt;0) &amp;&amp; (compare(y, z)&gt;0))</tt> implies
         * <tt>compare(x, z)&gt;0</tt>.<p>
         *
         * Finally, the implementer must ensure that <tt>compare(x, y)==0</tt>
         * implies that <tt>sgn(compare(x, z))==sgn(compare(y, z))</tt> for all
         * <tt>z</tt>.<p>
         *
         * It is generally the case, but <i>not</i> strictly required that 
         * <tt>(compare(x, y)==0) == (x.equals(y))</tt>.  Generally speaking,
         * any comparator that violates this condition should clearly indicate
         * this fact.  The recommended language is "Note: this comparator
         * imposes orderings that are inconsistent with equals."
         * 
         * @param o1 the first object to be compared.
         * @param o2 the second object to be compared.
         * @return a negative integer, zero, or a positive integer as the
         *         first argument is less than, equal to, or greater than the
         *         second. 
         */
        int compare(int o1, int o2);
    }
    
    /**
     * Sorts the specified array of objects according to the order induced by
     * the specified comparator.
     *
     * This sort is guaranteed to be <i>stable</i>:  equal elements will
     * not be reordered as a result of the sort.<p>
     *
     * The sorting algorithm is a modified mergesort (in which the merge is
     * omitted if the highest element in the low sublist is less than the
     * lowest element in the high sublist).  This algorithm offers guaranteed
     * n*log(n) performance. 
     *
     * @param a the array to be sorted.
     * @param c the comparator to determine the order of the array.
     * @see IIntComparator
     */
    public static void sort(int[] a, IIntComparator c) {
        int[] aux =  a.clone();
        mergeSort(aux, a, 0, a.length, 0, c);
    }
    
    /**
     * Sorts the specified array of objects according to the order induced by
     * the specified comparator.
     *
     * This sort is guaranteed to be <i>stable</i>:  equal elements will
     * not be reordered as a result of the sort.<p>
     *
     * The sorting algorithm is a modified mergesort (in which the merge is
     * omitted if the highest element in the low sublist is less than the
     * lowest element in the high sublist).  This algorithm offers guaranteed
     * n*log(n) performance. 
     *
     * @param a the array to be sorted.
     * @param fromIndex the index of the first element (inclusive) to be
     *        sorted.
     * @param toIndex the index of the last element (exclusive) to be sorted.
     * @param c the comparator to determine the order of the array.
     * @see IIntComparator
     */
    public static void sort(int[] a, int fromIndex, int toIndex, 
            IIntComparator c) {
        rangeCheck(a.length, fromIndex, toIndex);
        /*
         * cloneSubarray
         */
        int n = toIndex - fromIndex;
        int[] aux = new int[n];
        System.arraycopy(a, fromIndex, aux, 0, n);
        
        mergeSort(aux, a, fromIndex, toIndex, -fromIndex, c);
    }
    /**
     * Src is the source array that starts at index 0
     * Dest is the (possibly larger) array destination with a possible offset
     * low is the index in dest to start sorting
     * high is the end index in dest to end sorting
     * off is the offset into src corresponding to low in dest
     */
    private static void mergeSort(int[] src, int[] dest, int low, int high, 
            int off, IIntComparator c) {
        int length = high - low;

        // Insertion sort on smallest arrays
        if (length < INSERTIONSORT_THRESHOLD) {
            for (int i=low; i<high; i++)
                for (int j=i; j>low && c.compare(dest[j-1], dest[j])>0; j--) {
                    int t = dest[j];
                    dest[j] = dest[j - 1];
                    dest[j - 1] = t;
                } // for j
            return;
        }

        // Recursively sort halves of dest into src
        int destLow  = low;
        int destHigh = high;
        low  += off;
        high += off;
        int mid = (low + high) >>> 1;
        mergeSort(dest, src, low, mid, -off, c);
        mergeSort(dest, src, mid, high, -off, c);

        // If list is already sorted, just copy from src to dest.  This is an
        // optimization that results in faster sorts for nearly ordered lists.
        if (c.compare(src[mid-1], src[mid]) <= 0) {
           System.arraycopy(src, low, dest, destLow, length);
           return;
        }

        // Merge sorted halves (now in src) into dest
        for(int i = destLow, p = low, q = mid; i < destHigh; i++) {
            if (q >= high || p < mid && c.compare(src[p], src[q]) <= 0)
                dest[i] = src[p++];
            else
                dest[i] = src[q++];
        }
    }
}
