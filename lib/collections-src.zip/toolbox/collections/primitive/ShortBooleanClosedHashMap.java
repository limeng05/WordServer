/**
 * @(#ShortBooleanClosedHashMap.java, 2010-8-6. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.BitSet;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Hash map using primitive <code>@PRIMITIVE@</code> values, adapted from IntHashSet in
 * tclib.
 * 
 * @author Dennis M. Sosnoski, zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ShortBooleanClosedHashMap implements ShortBooleanKeyValueIterable {

    /** Default fill fraction allowed before growing table. */
    private static final double DEFAULT_FILL = 0.5d; // zf: original value: 0.3d

    /** Minimum size used for table. */
    private static final int MINIMUM_SIZE = 31;

    /** Hash value multiplier to scramble bits before calculating slot. */
    private static final int KEY_MULTIPLIER = 517;

    /** Fill fraction allowed for table. */
    private double fill;

    /** Number of entries present in table. */
    private int size;

    /** Entries allowed before growing table. */
    private int limit;

    /** Offset added (modulo table size) to slot number on collision. */
    private int hitOffset;

    /** Array of key table slots. */
    private short[] keyTable;

    /** Array of value table slots. */
    private boolean[] valueTable;

    /** Array of slot occupied flags. */
    private BitSet flag;

    /**
     * Constructor with full specification.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     * @param fill
     *            fraction full allowed for table before growing
     */
    public ShortBooleanClosedHashMap(int capacity, double fill) {
        // check the passed in fill fraction
        if (fill <= 0.0d || fill >= 1.0d) {
            throw new IllegalArgumentException("fill value out of range");
        }
        this.fill = fill;

        // compute initial table size (ensuring odd)
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;

        // initialize the table information
        limit = (int) (capacity * fill);
        hitOffset = capacity / 2;
        flag = new BitSet(capacity);
        keyTable = new short[capacity];
        valueTable = new boolean[capacity];
    }

    /**
     * Constructor with only size supplied. Uses default value for fill
     * fraction.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     */
    public ShortBooleanClosedHashMap(int capacity) {
        this(capacity, DEFAULT_FILL);
    }

    /**
     * Default constructor.
     */
    public ShortBooleanClosedHashMap() {
        this(0);
    }

    /**
     * Step the slot number for an entry. Adds the collision offset (modulo the
     * table size) to the slot number.
     * 
     * @param slot
     *            slot number to be stepped
     * @return stepped slot number
     */
    private int stepSlot(int slot) {
        return (slot + hitOffset) % keyTable.length;
    }

    /**
     * Find free slot number for entry. Starts at the slot based directly on the
     * hashed key value. If this slot is already occupied, it adds the collision
     * offset (modulo the table size) to the slot number and checks that slot,
     * repeating until an unused slot is found.
     * 
     * @param slot
     *            initial slot computed from key
     * @return slot at which entry was added
     */
    private int freeSlot(int slot) {
        while (flag.get(slot)) {
            slot = stepSlot(slot);
        }
        return slot;
    }

    /**
     * Compute the base slot for a key.
     * 
     * @param key
     *            key value to be computed
     * @return base slot for key
     */
    private int computeSlot(short key) {
        int k = Hash.hashCode(key);
        return (k * KEY_MULTIPLIER & Integer.MAX_VALUE) % keyTable.length;
    }

    /**
     * Assign slot for key. Starts at the slot found by the hashed key value. If
     * this slot is already occupied, it steps the slot number and checks the
     * resulting slot, repeating until an unused slot is found. This method does
     * not check for duplicate keys, so it should only be used for internal
     * reordering of the tables.
     * 
     * @param key
     *            key to be added to table
     * @return slot at which key was added
     */
    private int assignSlot(short key, boolean value) {
        int slot = freeSlot(computeSlot(key));
        flag.set(slot);
        keyTable[slot] = key;
        valueTable[slot] = value;
        return slot;
    }

    /**
     * Internal find key in table.
     * 
     * @param key
     *            to be found in table
     * @return index of matching key, or <code>-index-1</code> of slot to be
     *         used for inserting key in table if not already present (always
     *         negative)
     */
    private int internalFind(short key) {
        int slot = computeSlot(key);
        while (flag.get(slot)) {
            if (key == keyTable[slot]) {
                return slot;
            }
            slot = stepSlot(slot);
        }
        return -slot - 1;
    }

    /**
     * Reinsert a key into the hash map. This method is designed for internal
     * use when the table is being modified, and does not adjust the count
     * present or check the table capacity.
     * 
     * @param slot
     *            position of key to be reinserted into hash map
     * @return <code>true</code> if the slot number used by the key has has
     *         changed, <code>false</code> if not
     */

    private boolean reinsert(int slot) {
        flag.clear(slot);
        return assignSlot(keyTable[slot], valueTable[slot]) != slot;
    }

    /**
     * Resize the base arrays after a size change. This implementation of the
     * abstract base class method allocates the new arrays and then calls
     * another method for handling the actual transfer of the key set from the
     * old arrays to the new ones.
     * 
     * @param newCapacity
     *            new size for base arrays
     */
    private void resize(int newCapacity) {
        // allocate the larger arrays
        BitSet oldFlag = flag;
        flag = new BitSet(newCapacity);
        short[] oldKeyTable = keyTable;
        keyTable = new short[newCapacity];
        boolean[] oldValueTable = valueTable;
        valueTable = new boolean[newCapacity];

        // reinsert all entries into new arrays
        for (int i = 0; i < oldKeyTable.length; i++) {
            if (oldFlag.get(i)) {
                assignSlot(oldKeyTable[i], oldValueTable[i]);
            }
        }
    }

    /**
     * Ensure that the table has the capacity for at least the specified number
     * of keys.
     * 
     * @param minCapacity
     *            minimum capacity to be guaranteed
     */
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > limit) {
            // find the array size required
            int newCapacity = keyTable.length;
            int newLimit = limit;
            while (newLimit < minCapacity) {
                newCapacity = newCapacity * 2 + 1;
                newLimit = (int) (newCapacity * fill);
            }

            // set parameters for new array size
            limit = newLimit;
            hitOffset = newCapacity / 2;

            // let the subclass handle the adjustments to data
            resize(newCapacity);
        }
    }

    /**
     * Add key and value to the map.
     * 
     * @param key
     *            key to be added to map
     * @param value
     *            value to be added to map
     * @param def
     * @return return <code>def</code> if key added to map, or the previous
     *         value for this key if already present in map
     */
    public boolean put(short key, boolean value, boolean def) {
        ensureCapacity(size + 1);
        int slot = internalFind(key);
        if (slot < 0) {
            size++;
            slot = -slot - 1;
            flag.set(slot);
            keyTable[slot] = key;
            valueTable[slot] = value;
            return def;
        } else {
            boolean oldValue = valueTable[slot];
            valueTable[slot] = value;
            return oldValue;
        }
    }

    /**
     * get value for this key in the map.
     * 
     * @param key
     *            key to find map
     * @param def
     * @return value for this key if key found in map, or def if not found
     */
    public boolean get(short key, boolean def) {
        int slot = internalFind(key);
        if (slot >= 0) {
            return valueTable[slot];
        } else {
            return def;
        }
    }

    /**
     * Check if a key is present in the table.
     * 
     * @param key
     *            key to be found
     * @return <code>true</code> if key found in table, <code>false</code> if
     *         not
     */
    public boolean containsKey(short key) {
        return internalFind(key) >= 0;
    }

    /**
     * Check if a value is present in the table.
     * 
     * @param value
     *            value to be found
     * @return <code>true</code> if value found in table, <code>false</code> if
     *         not
     */
    public boolean containsValue(boolean value) {
        for (int i = 0; i < keyTable.length; i++) {
            if (flag.get(i) && valueTable[i] == value) {
                return true;
            }
        }
        return false;
    }

    /**
     * Remove a key from the table.
     * 
     * @param key
     *            key to be removed from table
     * @param def
     * @return the value for this key if key successfully removed from set, or
     *         def if key not found in set
     */
    public boolean remove(short key, boolean def) {
        int slot = internalFind(key);
        if (slot >= 0) {
            flag.clear(slot);
            boolean value = valueTable[slot];
            size--;
            while (flag.get(slot = stepSlot(slot))) {
                reinsert(slot);
            }
            return value;
        } else {
            return def;
        }
    }

    /**
     * Set the table to the empty state. This method may need to be overridden
     * in cases where other information associated with the keys also needs to
     * be cleared.
     */
    public void clear() {
        flag.clear();
        size = 0;
    }

    /**
     * Returns the number of key-value mappings in this map.
     * 
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     * 
     * @return <tt>true</tt> if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Trim the capacity of this instance if its current fill rate is smaller
     * than the given <code>fill</code>.
     * 
     * @param fill
     */
    public void trim(double fill) {
        if (fill >= this.fill) {
            return;
        }
        double currentFill = (double) size / keyTable.length;
        if (currentFill < fill) {
            // calculate expected capacity
            int capacity = Math.max((int) (size / fill), MINIMUM_SIZE);
            capacity += (capacity + 1) % 2;
            limit = (int) (capacity * this.fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Trim the capacity of this instance to the given <code>capacity</code>.
     * 
     * @param capacity
     */
    public void trim(int capacity) {
        if (capacity < size) {
            return;
        }
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;
        if (capacity < keyTable.length) {
            limit = (int) (capacity * fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Get current bucket count(the underly array length) of this hash set.
     * 
     * @return
     */
    public int getBucketSize() {
        return keyTable.length;
    }

    /**
     * Returns an iterator over all of the key-value mappings. Note that element
     * removal is not implemented.
     */
    public ShortBooleanKeyValueIterator iterator() {
        return new ShortBooleanKeyValueIterator() {
            private int returnedCount;

            private int pos = -1;

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }

            @Override
            public void next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                pos++;
                while (!flag.get(pos)) {
                    pos++;
                }
                returnedCount++;
            }

            @Override
            public boolean hasNext() {
                return returnedCount < size;
            }

            @Override
            public boolean getValue() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return valueTable[pos];
            }

            @Override
            public short getKey() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return keyTable[pos];
            }
        };
    }

    /**
     * Returns a string representation of this map. The string representation
     * consists of a list of key-value mappings in the order returned by the
     * map's iterator, enclosed in braces (<tt>"{}"</tt>). Adjacent mappings are
     * separated by the characters <tt>", "</tt> (comma and space). Each
     * key-value mapping is rendered as the key followed by an equals sign (
     * <tt>"="</tt>) followed by the associated value. Keys and values are
     * converted to strings as by {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this map
     */
    @Override
    public String toString() {
        ShortBooleanKeyValueIterator i = iterator();
        if (!i.hasNext()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        for (;;) {
            i.next();
            sb.append(i.getKey()).append('=').append(i.getValue());
            if (!i.hasNext()) {
                return sb.append('}').toString();
            }
            sb.append(", ");
        }
    }
}
