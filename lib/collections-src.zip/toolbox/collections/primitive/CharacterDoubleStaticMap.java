/**
 * @(#)CharacterDoubleStaticMap.java, 2011-12-8. 
 * 
 * Copyright 2011 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.collections.ArrayUtils;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static map.
 * <p>
 * This class is mainly used to providing a static(read-only) set. The keys and
 * values are stored using sorted arrays and found using binary-search, so it is
 * memory efficiency compared with other set.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CharacterDoubleStaticMap implements CharacterDoubleKeyValueIterable {

    private final char[] keys;

    private final double[] values;

    /**
     * Construct a static map from existing map.
     * 
     * @param map
     *            contains the keys and values you want to contain in the static
     *            set.
     */
    public CharacterDoubleStaticMap(CharacterDoubleHashMap map) {
        keys = new char[map.size()];
        values = new double[map.size()];
        Iterator<CharacterDoubleHashMap.Entry> iter = map.iterator();
        for (int i = 0; i < map.size(); i++) {
            CharacterDoubleHashMap.Entry entry = iter.next();
            keys[i] = entry.getKey();
            values[i] = entry.getValue();
        }
        ArrayUtils.sortArrays(keys, values);
    }

    /**
     * Construct a static map from existing map.
     * 
     * @param map
     *            contains the keys and values you want to contain in the static
     *            set.
     */
    public CharacterDoubleStaticMap(CharacterDoubleClosedHashMap map) {
        keys = new char[map.size()];
        values = new double[map.size()];
        CharacterDoubleKeyValueIterator iter = map.iterator();
        for (int i = 0; i < map.size(); i++) {
            iter.next();
            keys[i] = iter.getKey();
            values[i] = iter.getValue();
        }
        ArrayUtils.sortArrays(keys, values);
    }

    /**
     * Construct a static map from existing map.
     * 
     * @param map
     *            contains the keys and values you want to contain in the static
     *            set.
     */
    public CharacterDoubleStaticMap(CharacterDoubleCompactHashMap map) {
        keys = new char[map.size()];
        values = new double[map.size()];
        CharacterDoubleKeyValueIterator iter = map.iterator();
        for (int i = 0; i < map.size(); i++) {
            iter.next();
            keys[i] = iter.getKey();
            values[i] = iter.getValue();
        }
        ArrayUtils.sortArrays(keys, values);
    }

    /**
     * get value for this key in the map.
     * 
     * @param key
     *            key to find map
     * @param def
     * @return value for this key if key found in map, or def if not found
     */
    public double get(char key, double def) {
        int index = Arrays.binarySearch(keys, key);
        if (index < 0) {
            return def;
        } else {
            return values[index];
        }
    }

    /**
     * Check if a key is present in the table.
     * 
     * @param key
     *            key to be found
     * @return <code>true</code> if key found in table, <code>false</code> if
     *         not
     */
    public boolean containsKey(char key) {
        return Arrays.binarySearch(keys, key) >= 0;
    }

    /**
     * Check if a value is present in the table.
     * 
     * @param value
     *            value to be found
     * @return <code>true</code> if value found in table, <code>false</code> if
     *         not
     */
    public boolean containsValue(double value) {
        for (double v: values) {
            if (v == value) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns the number of key-value mappings in this map.
     * 
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return keys.length;
    }

    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     * 
     * @return <tt>true</tt> if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return keys.length == 0;
    }

    /**
     * Returns an iterator over all of the key-value mappings. Note that element
     * removal is not implemented.
     */
    public CharacterDoubleKeyValueIterator iterator() {
        return new CharacterDoubleKeyValueIterator() {

            private int pos = -1;

            @Override
            public void remove() {
                throw new UnsupportedOperationException();
            }

            @Override
            public void next() {
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                pos++;
            }

            @Override
            public boolean hasNext() {
                return pos < keys.length - 1;
            }

            @Override
            public double getValue() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return values[pos];
            }

            @Override
            public char getKey() {
                if (pos < 0) {
                    throw new IllegalStateException();
                }
                return keys[pos];
            }
        };
    }
    
    /**
     * Returns a string representation of this map. The string representation
     * consists of a list of key-value mappings in the order returned by the
     * map's iterator, enclosed in braces (<tt>"{}"</tt>). Adjacent mappings are
     * separated by the characters <tt>", "</tt> (comma and space). Each
     * key-value mapping is rendered as the key followed by an equals sign (
     * <tt>"="</tt>) followed by the associated value. Keys and values are
     * converted to strings as by {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this map
     */
    @Override
    public String toString() {
        CharacterDoubleKeyValueIterator i = iterator();
        if (!i.hasNext()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        for (;;) {
            i.next();
            sb.append(i.getKey()).append('=').append(i.getValue());
            if (!i.hasNext()) {
                return sb.append('}').toString();
            }
            sb.append(", ");
        }
    }
}