/**
 * @(#)CharacterIntegerKeyValueIterable.java, 2012-10-2. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Implements this interface to indicate that the class can return a key value
 * iterator.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public interface CharacterIntegerKeyValueIterable {

    /**
     * Returns an iterator over a set of key value pairs.
     * 
     * @return an Iterator.
     */
    CharacterIntegerKeyValueIterator iterator();
}