/**
 * @(#)FloatClosedHashSet.java, 2010-8-3. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.BitSet;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Hash set using primitive <code>float</code> values, adapted from IntHashSet in
 * tclib.
 * 
 * @author Dennis M. Sosnoski, zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FloatClosedHashSet implements Iterable<Float> {

    /** Default fill fraction allowed before growing table. */
    private static final double DEFAULT_FILL = 0.5d; // zf: original value: 0.3d

    /** Minimum size used for table. */
    private static final int MINIMUM_SIZE = 31;

    /** Hash value multiplier to scramble bits before calculating slot. */
    private static final int KEY_MULTIPLIER = 517;

    /** Fill fraction allowed for table. */
    private double fill;

    /** Number of entries present in table. */
    private int size;

    /** Entries allowed before growing table. */
    private int limit;

    /** Offset added (modulo table size) to slot number on collision. */
    private int hitOffset;

    /** Array of key table slots. */
    private float[] table;

    /** Array of slot occupied flags. */
    private BitSet flag;

    /**
     * Constructor with full specification.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     * @param fill
     *            fraction full allowed for table before growing
     */
    public FloatClosedHashSet(int capacity, double fill) {
        // check the passed in fill fraction
        if (fill <= 0.0d || fill >= 1.0d) {
            throw new IllegalArgumentException("fill value out of range");
        }
        this.fill = fill;

        // compute initial table size (ensuring odd)
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;

        // initialize the table information
        limit = (int) (capacity * fill);
        hitOffset = capacity / 2;
        flag = new BitSet(capacity);
        table = new float[capacity];
    }

    /**
     * Constructor with only size supplied. Uses default value for fill
     * fraction.
     * 
     * @param capacity
     *            number of values to assume in initial sizing of table
     */
    public FloatClosedHashSet(int capacity) {
        this(capacity, DEFAULT_FILL);
    }

    /**
     * Default constructor.
     */
    public FloatClosedHashSet() {
        this(0, DEFAULT_FILL);
    }

    /**
     * Step the slot number for an entry. Adds the collision offset (modulo the
     * table size) to the slot number.
     * 
     * @param slot
     *            slot number to be stepped
     * @return stepped slot number
     */
    private int stepSlot(int slot) {
        return (slot + hitOffset) % table.length;
    }

    /**
     * Find free slot number for entry. Starts at the slot based directly on the
     * hashed key value. If this slot is already occupied, it adds the collision
     * offset (modulo the table size) to the slot number and checks that slot,
     * repeating until an unused slot is found.
     * 
     * @param slot
     *            initial slot computed from key
     * @return slot at which entry was added
     */
    private int freeSlot(int slot) {
        while (flag.get(slot)) {
            slot = stepSlot(slot);
        }
        return slot;
    }

    /**
     * Compute the base slot for a key.
     * 
     * @param key
     *            key value to be computed
     * @return base slot for key
     */
    private int computeSlot(float key) {
        int k = Hash.hashCode(key);
        return (k * KEY_MULTIPLIER & Integer.MAX_VALUE) % table.length;
    }

    /**
     * Assign slot for key. Starts at the slot found by the hashed key value. If
     * this slot is already occupied, it steps the slot number and checks the
     * resulting slot, repeating until an unused slot is found. This method does
     * not check for duplicate keys, so it should only be used for internal
     * reordering of the tables.
     * 
     * @param key
     *            key to be added to table
     * @return slot at which key was added
     */
    private int assignSlot(float key) {
        int slot = freeSlot(computeSlot(key));
        flag.set(slot);
        table[slot] = key;
        return slot;
    }

    /**
     * Internal find key in table.
     * 
     * @param key
     *            to be found in table
     * @return index of matching key, or <code>-index-1</code> of slot to be
     *         used for inserting key in table if not already present (always
     *         negative)
     */
    private int internalFind(float key) {
        int slot = computeSlot(key);
        while (flag.get(slot)) {
            if (key == table[slot]) {
                return slot;
            }
            slot = stepSlot(slot);
        }
        return -slot - 1;
    }

    /**
     * Reinsert a key into the hash map. This method is designed for internal
     * use when the table is being modified, and does not adjust the count
     * present or check the table capacity.
     * 
     * @param slot
     *            position of key to be reinserted into hash map
     * @return <code>true</code> if the slot number used by the key has has
     *         changed, <code>false</code> if not
     */
    private boolean reinsert(int slot) {
        flag.clear(slot);
        return assignSlot(table[slot]) != slot;
    }

    /**
     * Resize the base arrays after a size change. This implementation of the
     * abstract base class method allocates the new arrays and then calls
     * another method for handling the actual transfer of the key set from the
     * old arrays to the new ones.
     * 
     * @param newCapacity
     *            new size for base arrays
     */
    private void resize(int newCapacity) {
        // allocate the larger arrays
        BitSet oldFlag = flag;
        flag = new BitSet(newCapacity);
        float[] oldTable = table;
        table = new float[newCapacity];

        // reinsert all entries into new arrays
        for (int i = 0; i < oldTable.length; i++) {
            if (oldFlag.get(i)) {
                assignSlot(oldTable[i]);
            }
        }
    }

    /**
     * Ensure that the table has the capacity for at least the specified number
     * of keys.
     * 
     * @param minCapacity
     *            minimum capacity to be guaranteed
     */
    private void ensureCapacity(int minCapacity) {
        if (minCapacity > limit) {
            // find the array size required
            int newCapacity = table.length;
            int newLimit = limit;
            while (newLimit < minCapacity) {
                newCapacity = newCapacity * 2 + 1;
                newLimit = (int) (newCapacity * fill);
            }

            // set parameters for new array size
            limit = newLimit;
            hitOffset = newCapacity / 2;

            // let the subclass handle the adjustments to data
            resize(newCapacity);
        }
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * 
     * @param e
     *            element to be added to this set
     * @return <tt>true</tt> if this set did not already contain the specified
     *         element
     */
    public boolean add(float e) {
        ensureCapacity(size + 1);
        int slot = internalFind(e);
        if (slot < 0) {
            size++;
            slot = -slot - 1;
            flag.set(slot);
            table[slot] = e;
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns <tt>true</tt> if this set contains the specified element.
     * 
     * @param e
     *            element whose presence in this set is to be tested
     * @return <tt>true</tt> if this set contains the specified element
     */
    public boolean contains(float e) {
        return internalFind(e) >= 0;
    }

    /**
     * Removes the specified element from this set if it is present.
     * 
     * @param e
     *            element to be removed from this set, if present
     * @return <tt>true</tt> if the set contained the specified element
     */
    public boolean remove(float e) {
        int slot = internalFind(e);
        if (slot >= 0) {
            flag.clear(slot);
            size--;
            while (flag.get(slot = stepSlot(slot))) {
                reinsert(slot);
            }
            return true;
        } else {
            return false;
        }
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    public void clear() {
        flag.clear();
        size = 0;
    }

    /**
     * Return all elements in the set in an array.
     */
    public float[] toArray() {
        float[] a = new float[size];
        int j = 0;
        for (int i = 0; i < table.length; i++) {
            if (flag.get(i)) {
                a[j++] = table[i];
            }
        }
        return a;
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     * 
     * @return the number of elements in this set (its cardinality)
     */
    public int size() {
        return size;
    }

    /**
     * Trim the capacity of this instance if its current fill rate is smaller
     * than the given <code>fill</code>.
     * 
     * @param fill
     */
    public void trim(double fill) {
        if (fill >= this.fill) {
            return;
        }
        double currentFill = (double) size / table.length;
        if (currentFill < fill) {
            // calculate expected capacity
            int capacity = Math.max((int) (size / fill), MINIMUM_SIZE);
            capacity += (capacity + 1) % 2;
            limit = (int) (capacity * this.fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Trim the capacity of this instance to the given <code>capacity</code>.
     * 
     * @param capacity
     */
    public void trim(int capacity) {
        if (capacity < size) {
            return;
        }
        capacity = Math.max((int) (capacity / fill), MINIMUM_SIZE);
        capacity += (capacity + 1) % 2;
        if (capacity < table.length) {
            limit = (int) (capacity * fill);
            hitOffset = capacity / 2;
            resize(capacity);
        }
    }

    /**
     * Get current bucket count(the underly array length) of this hash set.
     * 
     * @return
     */
    public int getBucketSize() {
        return table.length;
    }

    /**
     * Returns <tt>true</tt> if this set contains no elements.
     * 
     * @return <tt>true</tt> if this set contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Return an iterator for all elements in the set. Note that element removal
     * is not implemented.
     */
    @Override
    public Iterator<Float> iterator() {
        return new Iterator<Float>() {
            int returnedCount;

            int i;

            public void remove() {
                throw new UnsupportedOperationException();
            }

            public Float next() {
                if (hasNext()) {
                    while (!flag.get(i)) {
                        i++;
                    }
                    returnedCount++;
                    return table[i++];
                } else {
                    throw new NoSuchElementException();
                }
            }

            public boolean hasNext() {
                return returnedCount < size;
            }

        };
    }

    /**
     * Returns a string representation of this set. The string representation
     * consists of a list of the collection's elements in the order they are
     * returned by its iterator, enclosed in square brackets ( <tt>"[]"</tt>).
     * Adjacent elements are separated by the characters <tt>", "</tt> (comma
     * and space). Elements are converted to strings as by
     * {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this set
     */
    @Override
    public String toString() {
        Iterator<Float> i = iterator();
        if (!i.hasNext()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (;;) {
            sb.append(i.next());
            if (!i.hasNext()) {
                return sb.append(']').toString();
            }
            sb.append(", ");
        }
    }
}
