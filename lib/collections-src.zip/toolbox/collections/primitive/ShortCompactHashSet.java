/**
 * @(#)ShortCompactHashSet.java, 2012-9-30. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.nio.BufferOverflowException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A hash set use two primitive arrays to store keys and next pointers.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ShortCompactHashSet implements Iterable<Short> {
    private static final int MAXIMUM_CAPACITY = 1 << 30;

    private static final int DEFAULT_INITIAL_CAPACITY = 16;

    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    private static final int NEXT_VALUE_SLOT_EMPTY = 0;

    private static final int NEXT_VALUE_NEXT_NULL = -1;

    private short[] table;

    private int[] nexts;

    private int size;

    // we use the tail space to store conflict entries, 
    // [freeSegmentHead, keys.length) is empty. The value may increase if
    // we store some conflict entries, but never decrease. we handle removing in
    // conflict area by freeListHead.
    private int freeSegmentHead;

    // The deleted conflict entries is linked in a chain, freeListHead is the 
    // chain head. When we delete a conflict entry, we will link it into the 
    // chain and update freeListHead.
    private int freeListHead;

    private final float loadFactor;

    private int capacity;

    private int threshold;

    /**
     * Constructs an empty <tt>HashSet</tt> with the default initial capacity
     * (16) and the default load factor (0.75).
     */
    public ShortCompactHashSet() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    /**
     * Constructs an empty <tt>HashSet</tt> with the specified initial capacity.
     * 
     * @param initialCapacity
     *            the initial capacity
     */
    public ShortCompactHashSet(int initialCapacity) {
        this(initialCapacity, DEFAULT_LOAD_FACTOR);
    }

    /**
     * Constructs an empty <tt>HashSet</tt> with the specified initial capacity
     * and load factor.
     * 
     * @param initialCapacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     */
    public ShortCompactHashSet(int initialCapacity, float loadFactor) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("Illegal initial capacity: "
                    + initialCapacity);
        }
        if (loadFactor <= 0 || loadFactor > 1.0 || Float.isNaN(loadFactor)) {
            throw new IllegalArgumentException("Illegal load factor: "
                    + loadFactor);
        }
        if (initialCapacity > MAXIMUM_CAPACITY) {
            initialCapacity = MAXIMUM_CAPACITY;
        }
        int capacity = 1;
        while (capacity < initialCapacity) {
            capacity <<= 1;
        }
        this.capacity = capacity;
        this.loadFactor = loadFactor;
        this.threshold = (int) (capacity * loadFactor);
        table = new short[capacity + threshold];
        nexts = new int[capacity + threshold];
        freeSegmentHead = freeListHead = capacity;
    }

    private void resize(int newCapacity) {
        int newThreshold = (int) (newCapacity * loadFactor);
        short[] newTable = new short[newCapacity + newThreshold];
        int[] newNexts = new int[newCapacity + newThreshold];
        int newFreeSegmentHead = newCapacity;
        for (int i = 0; i < capacity; i++) {
            if (nexts[i] == NEXT_VALUE_SLOT_EMPTY) {
                continue;
            }
            for (int current = i;;) {
                int index = index(table[current], newCapacity);
                if (newNexts[index] == NEXT_VALUE_SLOT_EMPTY) {
                    newTable[index] = table[current];
                    newNexts[index] = NEXT_VALUE_NEXT_NULL;
                } else {
                    newTable[newFreeSegmentHead] = table[current];
                    newNexts[newFreeSegmentHead] = newNexts[index];
                    newNexts[index] = newFreeSegmentHead;
                    newFreeSegmentHead++;
                }
                current = nexts[current];
                if (current == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
        }
        table = newTable;
        nexts = newNexts;
        capacity = newCapacity;
        freeSegmentHead = freeListHead = newFreeSegmentHead;
        threshold = newThreshold;
    }

    /**
     * Calculate the index of a given short key. This code is migrated from jdk
     * source.
     * 
     * @param key
     * @param size
     * @return
     */
    private int index(short key, int size) {
        int h = Hash.hashCode(key);
        h += (h << 9);
        h ^= (h >>> 14);
        h += (h << 4);
        h ^= (h >> 10);
        return h & (size - 1);
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * 
     * @param e
     *            element to be added to this set
     * @return <tt>true</tt> if this set did not already contain the specified
     *         element
     */
    public boolean add(short e) {
        int index = index(e, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            table[index] = e;
            nexts[index] = NEXT_VALUE_NEXT_NULL;
        } else {
            for (int current = index;;) {
                if (table[current] == e) {
                    return false;
                }
                current = nexts[current];
                if (current == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
            if (freeListHead == table.length) {
                throw new BufferOverflowException();
            }
            int newIndex = freeListHead;
            if (freeListHead == freeSegmentHead) {
                freeListHead = ++freeSegmentHead;
            } else {
                freeListHead = nexts[freeListHead];
            }
            table[newIndex] = e;
            nexts[newIndex] = nexts[index];
            nexts[index] = newIndex;
        }
        size++;
        if (size > threshold && capacity < MAXIMUM_CAPACITY) {
            resize(capacity * 2);
        }
        return true;
    }

    /**
     * Returns <tt>true</tt> if this set contains the specified element.
     * 
     * @param e
     *            element whose presence in this set is to be tested
     * @return <tt>true</tt> if this set contains the specified element
     */
    public boolean contains(short e) {
        int index = index(e, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            return false;
        }
        do {
            if (table[index] == e) {
                return true;
            }
        } while ((index = nexts[index]) != NEXT_VALUE_NEXT_NULL);
        return false;
    }

    private void freeSlot(int index) {
        nexts[index] = freeListHead;
        freeListHead = index;
    }

    /**
     * Removes the specified element from this set if it is present.
     * 
     * @param e
     *            element to be removed from this set, if present
     * @return <tt>true</tt> if the set contained the specified element
     */
    public boolean remove(short e) {
        int index = index(e, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            return false;
        }
        int next = nexts[index];
        if (table[index] == e) {
            if (next == NEXT_VALUE_NEXT_NULL) {
                nexts[index] = NEXT_VALUE_SLOT_EMPTY;
            } else {
                table[index] = table[next];
                nexts[index] = nexts[next];
                freeSlot(next);
            }
            size--;
            return true;
        }
        while (next != NEXT_VALUE_NEXT_NULL) {
            if (table[next] == e) {
                nexts[index] = nexts[next];
                freeSlot(next);
                size--;
                return true;
            }
            index = next;
            next = nexts[next];
        }
        return false;
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    public void clear() {
        size = 0;
        freeListHead = freeSegmentHead = capacity;
        Arrays.fill(nexts, 0, capacity, NEXT_VALUE_SLOT_EMPTY);
    }

    /**
     * Return all elements in the set in an array.
     */
    public short[] toArray() {
        short[] a = new short[size];
        int j = 0;
        for (int i = 0; i < capacity; i++) {
            if (nexts[i] == NEXT_VALUE_SLOT_EMPTY) {
                continue;
            }
            for (int current = i;;) {
                a[j++] = table[current];
                current = nexts[current];
                if (current == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
        }
        return a;
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     * 
     * @return the number of elements in this set (its cardinality)
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this set contains no elements.
     * 
     * @return <tt>true</tt> if this set contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    private class IteratorImpl implements Iterator<Short> {

        private int index; // current slot

        private int current, next;

        public IteratorImpl() {
            current = NEXT_VALUE_NEXT_NULL;
            if (size == 0) {
                next = NEXT_VALUE_NEXT_NULL;
                return;
            }
            for (index = 0; nexts[index] == NEXT_VALUE_SLOT_EMPTY; index++);
            next = index;
        }

        @Override
        public boolean hasNext() {
            return next != NEXT_VALUE_NEXT_NULL;
        }

        @Override
        public Short next() {
            if (next == NEXT_VALUE_NEXT_NULL) {
                throw new NoSuchElementException();
            }
            current = next;
            next = nexts[next];
            if (next == NEXT_VALUE_NEXT_NULL) {
                for (++index; index < capacity
                        && nexts[index] == NEXT_VALUE_SLOT_EMPTY; index++);
                if (index < capacity) {
                    next = index;
                } else {
                    next = NEXT_VALUE_NEXT_NULL;
                }
            }
            return table[current];
        }

        @Override
        public void remove() {
            if (current == NEXT_VALUE_NEXT_NULL) {
                throw new IllegalStateException();
            }
            if (current >= capacity) {
                ShortCompactHashSet.this.remove(table[current]);
            } else {
                int next = nexts[current];
                if (next == NEXT_VALUE_NEXT_NULL) {
                    nexts[current] = NEXT_VALUE_SLOT_EMPTY;
                } else {
                    table[current] = table[next];
                    nexts[current] = nexts[next];
                    freeSlot(next);
                    this.next = current;
                }
                size--;
            }

            current = NEXT_VALUE_NEXT_NULL;
        }

    }

    /**
     * Returns an iterator over the elements in this set.
     */
    @Override
    public Iterator<Short> iterator() {
        return new IteratorImpl();
    }

    /**
     * Returns a string representation of this set. The string representation
     * consists of a list of the collection's elements in the order they are
     * returned by its iterator, enclosed in square brackets ( <tt>"[]"</tt>).
     * Adjacent elements are separated by the characters <tt>", "</tt> (comma
     * and space). Elements are converted to strings as by
     * {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this set
     */
    @Override
    public String toString() {
        Iterator<Short> i = iterator();
        if (!i.hasNext()) {
            return "[]";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('[');
        for (;;) {
            sb.append(i.next());
            if (!i.hasNext()) {
                return sb.append(']').toString();
            }
            sb.append(", ");
        }
    }

}
