/**
 * @(#)LongArrayList.java, 2010-7-26.
 * 
 * Copyright 2009 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Arrays;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A list base on array.
 *
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class LongArrayList {

    private long[] elementData;

    private int size;

    private static int DEFAULT_CAPACITY = 20;

    /**
     * Constructs an empty list with an initial capacity of 20.
     */
    public LongArrayList() {
        this(DEFAULT_CAPACITY);
    }

    /**
     * Constructs an empty list with the specified initial capacity.
     * 
     * @param capacity
     *            the initial capacity of the list
     */
    public LongArrayList(int capacity) {
        elementData = new long[capacity];
    }

    /**
     * Returns the number of elements in this list.
     * 
     * @return the number of elements in this list
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this list contains no elements.
     * 
     * @return <tt>true</tt> if this list contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns the index of the first occurrence of the specified element in
     * this list, or -1 if this list does not contain the element.
     */
    public int indexOf(long e) {
        for (int i = 0; i < size; i++) {
            if (elementData[i] == e) {
                return i;
            }
        }
        return -1;
    }

    /**
     * Returns the index of the last occurrence of the specified element in this
     * list, or -1 if this list does not contain the element.
     */
    public int lastIndexOf(long e) {
        for (int i = size - 1; i >= 0; i--) {
            if (elementData[i] == e) {
                return i;
            }
        }
        return -1;
    }
    
    private void rangeCheck(int index) {
        if (index < 0 || index >= size) {
            throw new ArrayIndexOutOfBoundsException(index);
        }
    }

    /**
     * Returns the element at the specified position in this list.
     * 
     * @param index
     *            index of the element to return
     * @return the element at the specified position in this list
     */
    public long get(int index) {
        rangeCheck(index);
        return elementData[index];
    }

    /**
     * Appends the specified element to the end of this list.
     * 
     * @param e
     *            element to be appended to this list
     */
    public void add(long e) {
        ensureCapacity(size + 1);
        elementData[size++] = e;
    }

    /**
     * Appends the all the elements to the end of this list.
     * 
     * @param arr
     *            elements to be appended to this list
     */
    public void addAll(long[] arr) {
        addAll(arr, 0, arr.length);
    }

    /**
     * Appends the all the elements in range to the end of this list.
     * 
     * @param arr
     *            elements to be appended to this list
     * @param offset
     *            the start postion.
     * @param length
     *            element count
     */
    public void addAll(long[] arr, int offset, int length) {
        if (offset < 0) {
            throw new ArrayIndexOutOfBoundsException(offset);
        }
        if (length < 0) {
            throw new IllegalArgumentException("length " + length + " is less than zero");
        }
        if (offset + length > arr.length) {
            throw new ArrayIndexOutOfBoundsException(offset + length);
        }
        ensureCapacity(size + length);
        System.arraycopy(arr, offset, elementData, size, length);
        size += length;
    }

    /**
     * Inserts the specified element at the specified position in this list.
     * Shifts the element currently at that position (if any) and any subsequent
     * elements to the right (adds one to their indices).
     * 
     * @param e
     *            element to be inserted
     * @param index
     *            index at which the specified element is to be inserted
     */
    public void insert(long e, int index) {
        rangeCheck(index);
        ensureCapacity(size + 1);
        System.arraycopy(elementData, index, elementData, index + 1, size
                - index);
        elementData[index] = e;
        size++;
    }

    /**
     * Replaces the element at the specified position in this list with the
     * specified element.
     * 
     * @param e
     *            element to be stored at the specified position
     * @param index
     *            index of the element to replace
     * @return the element previously at the specified position
     */
    public long set(long e, int index) {
        rangeCheck(index);
        long val = elementData[index];
        elementData[index] = e;
        return val;
    }

    /**
     * Removes the element at the specified position in this list. Shifts any
     * subsequent elements to the left (subtracts one from their indices).
     * 
     * @param index
     *            the index of the element to be removed
     * @return the element that was removed from the list
     */
    public long removeAt(int index) {
        rangeCheck(index);
        long val = elementData[index];
        removeAtInternal(index);
        return val;
    }

    private void removeAtInternal(int index) {
        int numMoved = size - index - 1;
        if (numMoved > 0) {
            System.arraycopy(elementData, index + 1, elementData, index,
                    numMoved);
        }
        size--;
    }

    /**
     * Removes the first occurrence of the specified element from this list, if
     * it is present. If the list does not contain the element, it is unchanged.
     * 
     * @param e
     *            element to be removed from this list, if present
     * @return <tt>true</tt> if this list contained the specified element
     */
    public boolean remove(long e) {
        for (int i = 0; i < size; i++) {
            if (elementData[i] == e) {
                removeAtInternal(i);
                return true;
            }
        }
        return false;
    }

    /**
     * Returns an array containing all of the elements in this list in proper
     * sequence (from first to last element).
     * <p>
     * The returned array will be "safe" in that no references to it are
     * maintained by this list. (In other words, this method must allocate a new
     * array). The caller is thus free to modify the returned array.
     */
    public long[] toArray() {
        long[] arr = new long[size];
        System.arraycopy(elementData, 0, arr, 0, size);
        return arr;
    }

    /**
     * Removes all of the elements from this list. The list will be empty after
     * this call returns.
     */
    public void clear() {
        size = 0;
    }

    /**
     * Trims the capacity of this instance to be the list's current size.
     */
    public void trimToSize() {
        int oldCapacity = elementData.length;
        if (size < oldCapacity) {
            elementData = Arrays.copyOf(elementData, size);
        }
    }

    /**
     * Trims the capacity of this instance to the given <code>capacity</code> if
     * the list's current capacity is larger than the given
     * <code>capacity</code>.
     * 
     * @param capacity
     */
    public void trim(int capacity) {
        if (elementData.length > capacity && capacity >= size) {
            long[] newElementData = new long[capacity];
            System.arraycopy(elementData, 0, newElementData, 0, size);
            elementData = newElementData;
        }
    }

    /**
     * Increases the capacity of this instance, if necessary, to ensure that it
     * can hold at least the number of elements specified by the minimum
     * capacity argument.
     * 
     * @param minCapacity
     *            the desired minimum capacity
     */
    public void ensureCapacity(int minCapacity) {
        int oldCapacity = elementData.length;
        if (minCapacity > oldCapacity) {
            int newCapacity = (oldCapacity * 3) / 2 + 1;
            if (newCapacity < minCapacity) {
                newCapacity = minCapacity;
            }
            elementData = Arrays.copyOf(elementData, newCapacity);
        }
    }

    /**
     * Get the array buffer directly in this instance.
     * <p>
     * <strong>NOTE:</strong> this operation is not safe, change the element in
     * the returned array will effect this instance.
     */
    public long[] getArray() {
        return elementData;
    }

    /**
     * Returns a string representation of this list. The string representation
     * consists of a list of the collection's elements in the order they are
     * returned by its iterator, enclosed in square brackets ( <tt>"[]"</tt>).
     * Adjacent elements are separated by the characters <tt>", "</tt> (comma
     * and space). Elements are converted to strings as by
     * {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this list
     */
    @Override
    public String toString() {
        int iMax = size - 1;
        if (iMax == -1) {
            return "[]";
        }

        StringBuilder b = new StringBuilder();
        b.append('[');
        for (int i = 0;; i++) {
            b.append(elementData[i]);
            if (i == iMax) {
                return b.append(']').toString();
            }
            b.append(", ");
        }
    }
}