/**
 * @(#)ByteHashSet.java, 2010-7-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.BitSet;
import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A set for primitive <code>byte</code> values using BitSet.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class ByteSet implements Iterable<Byte> {

    private static final int FLAG_SIZE = (int) Byte.MAX_VALUE - Byte.MIN_VALUE
            + 1;

    private BitSet flag = new BitSet(FLAG_SIZE);

    private int size;

    /**
     * Returns the number of elements in this set (its cardinality).
     * 
     * @return the number of elements in this set (its cardinality)
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this set contains no elements.
     * 
     * @return <tt>true</tt> if this set contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    private int index(byte e) {
        return (int) e - Byte.MIN_VALUE;
    }

    private byte value(int index) {
        return (byte) (Byte.MIN_VALUE + index);
    }

    /**
     * Returns <tt>true</tt> if this set contains the specified element.
     * 
     * @param e
     *            element whose presence in this set is to be tested
     * @return <tt>true</tt> if this set contains the specified element
     */
    public boolean contains(byte e) {
        return flag.get((int) e - Byte.MIN_VALUE);
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * 
     * @param e
     *            element to be added to this set
     * @return <tt>true</tt> if this set did not already contain the specified
     *         element
     */
    public boolean add(byte e) {
        int index = index(e);
        if (flag.get(index)) {
            return false;
        }
        flag.set(index);
        size++;
        return true;
    }

    /**
     * Removes the specified element from this set if it is present.
     * 
     * @param e
     *            element to be removed from this set, if present
     * @return <tt>true</tt> if the set contained the specified element
     */
    public boolean remove(byte e) {
        int index = index(e);
        if (flag.get(index)) {
            flag.clear(index);
            size--;
            return true;
        }
        return false;
    }

    /**
     * Returns an array containing all of the elements in this set.
     */
    public byte[] toArray() {
        byte[] arr = new byte[size];
        int start = -1;
        for (int i = 0; i < size; i++) {
            start = flag.nextSetBit(start + 1);
            arr[i] = (byte) (start + Byte.MIN_VALUE);
        }
        return arr;
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    public void clear() {
        flag.clear();
        size = 0;
    }

    /**
     * Returns an iterator over the elements in this set.
     */
    @Override
    public Iterator<Byte> iterator() {
        return new Iterator<Byte>() {

            private int returned;

            private int i = -1;

            @Override
            public boolean hasNext() {
                return returned < size;
            }

            @Override
            public Byte next() {
                if (i == -1) {
                    i = 0;
                }
                while (i < FLAG_SIZE && !flag.get(i)) {
                    i++;
                }
                if (i == FLAG_SIZE) {
                    i = -2;
                    return null;
                }
                return value(i);
            }

            @Override
            public void remove() {
                if (i < 0) {
                    throw new NoSuchElementException();
                }
                flag.clear(i);
                size--;
            }

        };
    }

}
