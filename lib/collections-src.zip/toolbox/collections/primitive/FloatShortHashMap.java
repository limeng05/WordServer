/**
 * @(#)FloatShortHashMap.java, 2010-7-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Iterator;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Hash map using primitive <code>@PRIMITIVE@</code> values.
 *
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FloatShortHashMap implements Iterable<FloatShortHashMap.Entry> {
    private static final int MAX_CAPACITY = 1 << 30;

    private static final int DEFAULT_INITIAL_CAPACITY = 16;

    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    private Entry[] table;

    private int size;

    private float loadFactor;

    private int expandSize;

    /**
     * Constructs an empty <tt>HashMap</tt> with the default initial capacity
     * (16) and the default load factor (0.75).
     */
    public FloatShortHashMap() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    /**
     * Constructs an empty <tt>HashMap</tt> with the specified initial capacity.
     * 
     * @param capacity
     *            the initial capacity
     */
    public FloatShortHashMap(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }

    /**
     * Constructs an empty <tt>HashMap</tt> with the specified initial capacity
     * and load factor.
     * 
     * @param capacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     */
    public FloatShortHashMap(int capacity, float loadFactor) {
        int realSize = 1;
        while (realSize < capacity) {
            realSize = realSize << 1;
        }
        if (realSize > MAX_CAPACITY)
            realSize = MAX_CAPACITY;

        table = new Entry[realSize];
        expandSize = (int) (table.length * loadFactor);
        size = 0;

        this.loadFactor = loadFactor;
    }

    private void resize(int capacity) {
        Entry[] newTable = new Entry[capacity];

        for (Entry entry: table) {
            while (entry != null) {
                Entry tmp = entry.next;
                int index = index(entry.key, capacity);
                entry.next = newTable[index];
                newTable[index] = entry;
                entry = tmp;
            }
        }

        table = newTable;
        expandSize = (int) (table.length * loadFactor);
    }

    /**
     * Calculate the index of a given float key. This code is migrated from jdk
     * source.
     * 
     * @param key
     * @param size
     * @return
     */
    private int index(float key, int size) {
        int h = Hash.hashCode(key);
        h += (h << 9);
        h ^= (h >>> 14);
        h += (h << 4);
        h ^= (h >> 10);
        return h & (size - 1);
    }

    /**
     * Returns the value to which the specified key is mapped, or
     * <code>def</code> if this map contains no mapping for the key.
     */
    public short get(float key, short def) {
        int index = index(key, table.length);
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                return entry.value;
            }
            entry = entry.next;
        }
        return def;
    }

    /**
     * Returns <tt>true</tt> if this map contains a mapping for the specified
     * key.
     * 
     * @param key
     *            The key whose presence in this map is to be tested
     * @return <tt>true</tt> if this map contains a mapping for the specified
     *         key.
     */
    public boolean containsKey(float key) {
        int index = index(key, table.length);
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                return true;
            }
            entry = entry.next;
        }
        return false;
    }
    /**
     * Returns <tt>true</tt> if this map maps one or more keys to the specified
     * value.
     * 
     * @param value
     *            value whose presence in this map is to be tested
     * @return <tt>true</tt> if this map maps one or more keys to the specified
     *         value
     */
    public boolean containsValue(short value) {
        Entry[] tab = table;
        for (int i = 0; i < tab.length; i++)
            for (Entry e = tab[i]; e != null; e = e.next)
                if (value == e.value) {
                    return true;
                }
        return false;
    }

    /**
     * Associates the specified value with the specified key in this map. If the
     * map previously contained a mapping for the key, the old value is
     * replaced.
     * 
     * @param key
     *            key with which the specified value is to be associated
     * @param value
     *            value to be associated with the specified key
     * @return the previous value associated with <tt>key</tt>, or <tt>def</tt>
     *         if there was no mapping for <tt>key</tt>.
     */
    public short put(float key, short value, short def) {
        if (size > expandSize && table.length < MAX_CAPACITY) {
            resize(table.length << 1);
        }
        int index = index(key, table.length);
        Entry entry = table[index];
        while (entry != null) {
            if (entry.key == key) {
                short ret = entry.value;
                entry.value = value;
                return ret;
            }
            entry = entry.next;
        }
        entry = new Entry(key, value);
        entry.next = table[index];
        table[index] = entry;
        size++;
        return def;
    }

    /**
     * Removes the mapping for the specified key from this map if present.
     * 
     * @param key
     *            key whose mapping is to be removed from the map
     * @return the previous value associated with <tt>key</tt>, or <tt>def</tt>
     *         if there was no mapping for <tt>key</tt>.
     */
    public short remove(float key, short def) {
        int index = index(key, table.length);
        Entry entry = table[index];
        if (entry != null) {
            if (entry.key == key) {
                table[index] = entry.next;
                size--;
                return entry.value;
            } else {
                while (entry.next != null)
                    if (entry.next.key == key) {
                        short value = entry.next.value;
                        entry.next = entry.next.next;
                        size--;
                        return value;
                    } else {
                        entry = entry.next;
                    }
            }
        }
        return def;
    }

    /**
     * Returns an iterator over the key-value mappings in this map.
     */
    public Iterator<Entry> iterator() {
        return new FloatShortHashIterator();
    }

    /**
     * Returns the number of key-value mappings in this map.
     * 
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     * 
     * @return <tt>true</tt> if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Removes all of the mappings from this map. The map will be empty after
     * this call returns.
     */
    public void clear() {
        for (int i = 0; i < table.length; i++) {
            table[i] = null;
        }
        size = 0;
    }

    /**
     * Returns a string representation of this map.  The string representation
     * consists of a list of key-value mappings in the order returned by the
     * map's iterator, enclosed in braces
     * (<tt>"{}"</tt>).  Adjacent mappings are separated by the characters
     * <tt>", "</tt> (comma and space).  Each key-value mapping is rendered as
     * the key followed by an equals sign (<tt>"="</tt>) followed by the
     * associated value.  Keys and values are converted to strings as by
     * {@link String#valueOf(Object)}.
     *
     * @return a string representation of this map
     */
    @Override
    public String toString() {
        Iterator<Entry> i = iterator();
        if (!i.hasNext()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        for (;;) {
            sb.append(i.next());
            if (!i.hasNext()) {
                return sb.append('}').toString();
            }
            sb.append(", ");
        }
    }
    
    /**
     * The key-value entry of hash map.
     * 
     * @author zhangduo
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public static class Entry {
        private final float key;

        private short value;

        private Entry next;

        Entry(float key, short value) {
            this.key = key;
            this.value = value;
            next = null;
        }

        /**
         * Get key.
         * 
         * @return
         */
        public float getKey() {
            return key;
        }

        /**
         * Get value.
         * 
         * @return
         */
        public short getValue() {
            return value;
        }

        /**
         * {@inheritDoc}
         */
        @Override
        public String toString() {
            return key + "=" + value;
        }
    }

    private class FloatShortHashIterator implements Iterator<Entry> {
        private int index; // current slot

        private Entry current, next;

        public FloatShortHashIterator() {
            Entry[] t = table;
            int i = t.length;
            Entry n = null;
            if (size != 0) { // advance to first entry
                while (i > 0 && (n = t[--i]) == null);
            }
            next = n;
            index = i;
        }

        public boolean hasNext() {
            return next != null;
        }

        public Entry next() {
            Entry e = next;
            if (e == null) {
                throw new NoSuchElementException();
            }
            Entry n = e.next;
            Entry[] t = table;
            int i = index;
            while (n == null && i > 0)
                n = t[--i];
            index = i;
            next = n;
            return current = e;
        }

        public void remove() {
            if (current == null) {
                throw new IllegalStateException();
            }
            float k = current.key;
            short v = current.value;
            current = null;
            FloatShortHashMap.this.remove(k, v);
        }

    }
}
