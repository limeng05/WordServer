/**
 * @(#)PrimitiveLinkedQueue.java, 2012-4-5. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * An FIFO queue implemented in linked list for primitive types.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class PrimitiveLinkedQueue {
    private static final class Entry {
        long value;

        Entry next;

        public Entry(long value, Entry next) {
            this.value = value;
            this.next = next;
        }

    }

    private Entry head, tail;

    private int size;

    /**
     * Returns <tt>true</tt> if this queue contains no elements.
     */
    public boolean isEmpty() {
        return head == null;
    }

    /**
     * Inserts the element into the queue.
     */
    public void add(long value) {
        if (tail == null) {
            head = tail = new Entry(value, null);
            size = 1;
        } else {
            tail.next = new Entry(value, null);
            tail = tail.next;
            size++;
        }
    }

    /**
     * Retrieves and removes the head of this queue.
     * 
     * @throws NoSuchElementException
     *             if this queue is empty
     */
    public long remove() {
        long value = element();
        if (head == tail) {
            head = tail = null;
        } else {
            head = head.next;
        }
        size--;
        return value;
    }

    /**
     * Retrieves, but does not remove, the head of this queue.
     * 
     * @throws NoSuchElementException
     *             if this queue is empty
     */
    public long element() {
        if (head == null) {
            throw new NoSuchElementException();
        }
        return head.value;
    }

    /**
     * Removes all of the elements from this queue.
     */
    public void clear() {
        head = tail = null;
        size = 0;
    }

    /**
     * Returns the number of elements in this queue.
     */
    public int size() {
        return size;
    }

}
