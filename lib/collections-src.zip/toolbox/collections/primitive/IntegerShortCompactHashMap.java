/**
 * @(#)IntegerShortCompactHashMap.java, 2012-9-29. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.nio.BufferOverflowException;
import java.util.Arrays;
import java.util.NoSuchElementException;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A hash map use three primitive arrays to store keys, values and next
 * pointers.
 * 
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class IntegerShortCompactHashMap implements IntegerShortKeyValueIterable {
    private static final int MAXIMUM_CAPACITY = 1 << 30;

    private static final int DEFAULT_INITIAL_CAPACITY = 16;

    private static final float DEFAULT_LOAD_FACTOR = 0.75f;

    private static final int NEXT_VALUE_SLOT_EMPTY = 0;

    private static final int NEXT_VALUE_NEXT_NULL = -1;

    private int[] keys;

    private short[] values;

    private int[] nexts;

    private int size;

    // we use the tail space to store conflict entries, 
    // [freeSegmentHead, keys.length) is empty. The value may increase if
    // we store some conflict entries, but never decrease. we handle removing in
    // conflict area by freeListHead.
    private int freeSegmentHead;

    // The deleted conflict entries is linked in a chain, freeListHead is the 
    // chain head. When we delete a conflict entry, we will link it into the 
    // chain and update freeListHead.
    private int freeListHead;

    private final float loadFactor;

    private int capacity;

    private int threshold;

    /**
     * Constructs an empty <tt>HashMap</tt> with the default initial capacity
     * (16) and the default load factor (0.75).
     */
    public IntegerShortCompactHashMap() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    /**
     * Constructs an empty <tt>HashMap</tt> with the specified initial capacity.
     * 
     * @param initialCapacity
     *            the initial capacity
     */
    public IntegerShortCompactHashMap(int initialCapacity) {
        this(initialCapacity, DEFAULT_LOAD_FACTOR);
    }

    /**
     * Constructs an empty <tt>HashMap</tt> with the specified initial capacity
     * and load factor.
     * 
     * @param initialCapacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     */
    public IntegerShortCompactHashMap(int initialCapacity, float loadFactor) {
        if (initialCapacity < 0) {
            throw new IllegalArgumentException("Illegal initial capacity: "
                    + initialCapacity);
        }
        if (loadFactor <= 0 || loadFactor > 1.0 || Float.isNaN(loadFactor)) {
            throw new IllegalArgumentException("Illegal load factor: "
                    + loadFactor);
        }
        if (initialCapacity > MAXIMUM_CAPACITY) {
            initialCapacity = MAXIMUM_CAPACITY;
        }
        int capacity = 1;
        while (capacity < initialCapacity) {
            capacity <<= 1;
        }
        this.capacity = capacity;
        this.loadFactor = loadFactor;
        this.threshold = (int) (capacity * loadFactor);
        keys = new int[capacity + threshold];
        values = new short[capacity + threshold];
        nexts = new int[capacity + threshold];
        freeSegmentHead = freeListHead = capacity;
    }

    private void resize(int newCapacity) {
        int newThreshold = (int) (newCapacity * loadFactor);
        int[] newKeys = new int[newCapacity + newThreshold];
        short[] newValues = new short[newCapacity + newThreshold];
        int[] newNexts = new int[newCapacity + newThreshold];
        int newFreeSegmentHead = newCapacity;
        for (int i = 0; i < capacity; i++) {
            if (nexts[i] == NEXT_VALUE_SLOT_EMPTY) {
                continue;
            }
            for (int current = i;;) {
                int index = index(keys[current], newCapacity);
                if (newNexts[index] == NEXT_VALUE_SLOT_EMPTY) {
                    newKeys[index] = keys[current];
                    newValues[index] = values[current];
                    newNexts[index] = NEXT_VALUE_NEXT_NULL;
                } else {
                    newKeys[newFreeSegmentHead] = keys[current];
                    newValues[newFreeSegmentHead] = values[current];
                    newNexts[newFreeSegmentHead] = newNexts[index];
                    newNexts[index] = newFreeSegmentHead;
                    newFreeSegmentHead++;
                }
                current = nexts[current];
                if (current == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
        }
        keys = newKeys;
        values = newValues;
        nexts = newNexts;
        capacity = newCapacity;
        freeSegmentHead = freeListHead = newFreeSegmentHead;
        threshold = newThreshold;
    }

    /**
     * Calculate the index of a given int key. This code is migrated from jdk
     * source.
     * 
     * @param key
     * @param size
     * @return
     */
    private int index(int key, int size) {
        int h = Hash.hashCode(key);
        h += (h << 9);
        h ^= (h >>> 14);
        h += (h << 4);
        h ^= (h >> 10);
        return h & (size - 1);
    }

    /**
     * Returns the value to which the specified key is mapped, or
     * <code>def</code> if this map contains no mapping for the key.
     */
    public short get(int key, short def) {
        int index = index(key, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            return def;
        }
        do {
            if (keys[index] == key) {
                return values[index];
            }
        } while ((index = nexts[index]) != NEXT_VALUE_NEXT_NULL);
        return def;
    }

    /**
     * Returns <tt>true</tt> if this map contains a mapping for the specified
     * key.
     * 
     * @param key
     *            The key whose presence in this map is to be tested
     * @return <tt>true</tt> if this map contains a mapping for the specified
     *         key.
     */
    public boolean containsKey(int key) {
        int index = index(key, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            return false;
        }
        do {
            if (keys[index] == key) {
                return true;
            }
        } while ((index = nexts[index]) != NEXT_VALUE_NEXT_NULL);
        return false;
    }

    /**
     * Returns <tt>true</tt> if this map maps one or more keys to the specified
     * value.
     * 
     * @param value
     *            value whose presence in this map is to be tested
     * @return <tt>true</tt> if this map maps one or more keys to the specified
     *         value
     */
    public boolean containsValue(short value) {
        for (int i = 0; i < capacity; i++) {
            if (nexts[i] == NEXT_VALUE_SLOT_EMPTY) {
                continue;
            }
            for (int index = i;;) {
                if (values[index] == value) {
                    return true;
                }
                index = nexts[index];
                if (index == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
        }
        return false;
    }

    /**
     * Associates the specified value with the specified key in this map. If the
     * map previously contained a mapping for the key, the old value is
     * replaced.
     * 
     * @param key
     *            key with which the specified value is to be associated
     * @param value
     *            value to be associated with the specified key
     * @return the previous value associated with <tt>key</tt>, or <tt>def</tt>
     *         if there was no mapping for <tt>key</tt>.
     */
    public short put(int key, short value, short def) {
        int index = index(key, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            keys[index] = key;
            values[index] = value;
            nexts[index] = NEXT_VALUE_NEXT_NULL;
        } else {
            for (int current = index;;) {
                if (keys[current] == key) {
                    short ret = values[current];
                    values[current] = value;
                    return ret;
                }
                current = nexts[current];
                if (current == NEXT_VALUE_NEXT_NULL) {
                    break;
                }
            }
            if (freeListHead == keys.length) {
                throw new BufferOverflowException();
            }
            int newIndex = freeListHead;
            if (freeListHead == freeSegmentHead) {
                freeListHead = ++freeSegmentHead;
            } else {
                freeListHead = nexts[freeListHead];
            }
            keys[newIndex] = key;
            values[newIndex] = value;
            nexts[newIndex] = nexts[index];
            nexts[index] = newIndex;
        }
        size++;
        if (size > threshold && capacity < MAXIMUM_CAPACITY) {
            resize(capacity * 2);
        }
        return def;
    }

    private void freeSlot(int index) {
        nexts[index] = freeListHead;
        freeListHead = index;
    }

    /**
     * Removes the mapping for the specified key from this map if present.
     * 
     * @param key
     *            key whose mapping is to be removed from the map
     * @return the previous value associated with <tt>key</tt>, or <tt>def</tt>
     *         if there was no mapping for <tt>key</tt>.
     */
    public short remove(int key, short def) {
        int index = index(key, capacity);
        if (nexts[index] == NEXT_VALUE_SLOT_EMPTY) {
            return def;
        }
        int next = nexts[index];
        if (keys[index] == key) {
            short ret = values[index];
            if (next == NEXT_VALUE_NEXT_NULL) {
                nexts[index] = NEXT_VALUE_SLOT_EMPTY;
            } else {
                keys[index] = keys[next];
                values[index] = values[next];
                nexts[index] = nexts[next];
                freeSlot(next);
            }
            size--;
            return ret;
        }
        while (next != NEXT_VALUE_NEXT_NULL) {
            if (keys[next] == key) {
                nexts[index] = nexts[next];
                freeSlot(next);
                size--;
                return values[next];
            }
            index = next;
            next = nexts[next];
        }
        return def;
    }

    private class IntegerShortKeyValueIteratorImpl implements
            IntegerShortKeyValueIterator {

        private int index; // current slot

        private int current, next;

        public IntegerShortKeyValueIteratorImpl() {
            current = NEXT_VALUE_NEXT_NULL;
            if (size == 0) {
                next = NEXT_VALUE_NEXT_NULL;
                return;
            }
            for (index = 0; nexts[index] == NEXT_VALUE_SLOT_EMPTY; index++);
            next = index;
        }

        @Override
        public boolean hasNext() {
            return next != NEXT_VALUE_NEXT_NULL;
        }

        @Override
        public void next() {
            if (next == NEXT_VALUE_NEXT_NULL) {
                throw new NoSuchElementException();
            }
            current = next;
            next = nexts[next];
            if (next == NEXT_VALUE_NEXT_NULL) {
                for (++index; index < capacity
                        && nexts[index] == NEXT_VALUE_SLOT_EMPTY; index++);
                if (index < capacity) {
                    next = index;
                } else {
                    next = NEXT_VALUE_NEXT_NULL;
                }
            }
        }

        @Override
        public int getKey() {
            if (current == NEXT_VALUE_NEXT_NULL) {
                throw new IllegalStateException();
            }

            return keys[current];
        }

        @Override
        public short getValue() {
            if (current == NEXT_VALUE_NEXT_NULL) {
                throw new IllegalStateException();
            }
            return values[current];
        }

        @Override
        public void remove() {
            if (current == NEXT_VALUE_NEXT_NULL) {
                throw new IllegalStateException();
            }
            if (current >= capacity) {
                IntegerShortCompactHashMap.this.remove(keys[current], values[current]);
            } else {
                int next = nexts[current];
                if (next == NEXT_VALUE_NEXT_NULL) {
                    nexts[current] = NEXT_VALUE_SLOT_EMPTY;
                } else {
                    keys[current] = keys[next];
                    values[current] = values[next];
                    nexts[current] = nexts[next];
                    freeSlot(next);
                    this.next = current;
                }
                size--;
            }

            current = NEXT_VALUE_NEXT_NULL;
        }

    }

    /**
     * Returns an iterator over the key-value mappings in this map.
     */
    public IntegerShortKeyValueIterator iterator() {
        return new IntegerShortKeyValueIteratorImpl();
    }

    /**
     * Returns the number of key-value mappings in this map.
     * 
     * @return the number of key-value mappings in this map
     */
    public int size() {
        return size;
    }

    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     * 
     * @return <tt>true</tt> if this map contains no key-value mappings
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Removes all of the mappings from this map. The map will be empty after
     * this call returns.
     */
    public void clear() {
        size = 0;
        freeListHead = freeSegmentHead = capacity;
        Arrays.fill(nexts, 0, capacity, NEXT_VALUE_SLOT_EMPTY);
    }

    /**
     * Returns a string representation of this map. The string representation
     * consists of a list of key-value mappings in the order returned by the
     * map's iterator, enclosed in braces (<tt>"{}"</tt>). Adjacent mappings are
     * separated by the characters <tt>", "</tt> (comma and space). Each
     * key-value mapping is rendered as the key followed by an equals sign (
     * <tt>"="</tt>) followed by the associated value. Keys and values are
     * converted to strings as by {@link String#valueOf(Object)}.
     * 
     * @return a string representation of this map
     */
    @Override
    public String toString() {
        IntegerShortKeyValueIterator i = iterator();
        if (!i.hasNext()) {
            return "{}";
        }

        StringBuilder sb = new StringBuilder();
        sb.append('{');
        for (;;) {
            i.next();
            sb.append(i.getKey()).append('=').append(i.getValue());
            if (!i.hasNext()) {
                return sb.append('}').toString();
            }
            sb.append(", ");
        }
    }
}
