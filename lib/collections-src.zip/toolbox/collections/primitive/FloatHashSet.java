/**
 * @(#)FloatHashSet.java, 2010-7-28. 
 * 
 * Copyright 2010 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections.primitive;

import java.util.Iterator;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Hash set using primitive <code>float</code> values.
 *
 * @author zhangduo
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class FloatHashSet implements Iterable<Float> {

    private FloatFloatHashMap map;

    /**
     * Constructs a new, empty set.
     */
    public FloatHashSet() {
        map = new FloatFloatHashMap();
    }

    /**
     * Constructs a new, empty set with the specified initial capacity.
     * 
     * @param capacity
     *            the initial capacity
     */
    public FloatHashSet(int capacity) {
        map = new FloatFloatHashMap(capacity);
    }

    /**
     * Constructs a new, empty set with the specified initial capacity and the
     * specified load factor.
     * 
     * @param capacity
     *            the initial capacity
     * @param loadFactor
     *            the load factor
     */
    public FloatHashSet(int capacity, float loadFactor) {
        map = new FloatFloatHashMap(capacity, loadFactor);
    }

    /**
     * Returns the number of elements in this set (its cardinality).
     * 
     * @return the number of elements in this set (its cardinality)
     */
    public int size() {
        return map.size();
    }

    /**
     * Returns <tt>true</tt> if this set contains no elements.
     * 
     * @return <tt>true</tt> if this set contains no elements
     */
    public boolean isEmpty() {
        return map.isEmpty();
    }

    /**
     * Returns <tt>true</tt> if this set contains the specified element.
     * 
     * @param e
     *            element whose presence in this set is to be tested
     * @return <tt>true</tt> if this set contains the specified element
     */
    public boolean contains(float e) {
        return map.containsKey(e);
    }

    /**
     * Adds the specified element to this set if it is not already present.
     * 
     * @param e
     *            element to be added to this set
     * @return <tt>true</tt> if this set did not already contain the specified
     *         element
     */
    public boolean add(float e) {
        return map.put(e, e, (float)(e + 1)) != e;
    }

    /**
     * Removes the specified element from this set if it is present.
     * 
     * @param e
     *            element to be removed from this set, if present
     * @return <tt>true</tt> if the set contained the specified element
     */
    public boolean remove(float e) {
        return map.remove(e, (float)(e + 1)) == e;
    }

    /**
     * Returns an array containing all of the elements in this set.
     */
    public float[] toArray() {
        float[] arr = new float[map.size()];
        Iterator<FloatFloatHashMap.Entry> iter = map.iterator();
        for (int i = 0; i < arr.length; i++) {
            arr[i] = iter.next().getKey();
        }
        return arr;
    }

    /**
     * Removes all of the elements from this set. The set will be empty after
     * this call returns.
     */
    public void clear() {
        map.clear();
    }

    /**
     * Returns an iterator over the elements in this set.
     */
    @Override
    public Iterator<Float> iterator() {
        final Iterator<FloatFloatHashMap.Entry> iter = map.iterator();
        return new Iterator<Float>() {

            @Override
            public boolean hasNext() {
                return iter.hasNext();
            }

            @Override
            public Float next() {
                return iter.next().getValue();
            }

            @Override
            public void remove() {
                iter.remove();
            }

        };
    }

}