package toolbox.collections;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static set-map (the map from key -> set<value>, here the set is represented
 * as a list without duplicated values).
 * 
 * This class is mainly used to providing a static look-up-table. It is memory
 * efficiency compared with HashMap<K, ArrayList<V>>();
 * 
 * Usage:
 *   StaticListMap<K, V> map = new StaticListMap<K, V>();
 *   
 *   map.put(key, value);
 *   ...
 *   // Calling to map.get(...) here is illegal and will cause an exception.
 *   
 *   map.sort();
 *   
 *   List<V> values = map.get(key); ...
 *   // Calling to map.put(...) here is illegal and will cause an exception.
 *   
 * Implementaion:
 *   Key-value pairs are stored in an array-list. In sorting method, the list
 *   are sorted. A binary-search is performed for searching values on the sorted
 *   list.
 *   
 * @author david
 *
 * @param <K>  the key
 * @param <V>  the value
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class StaticSetMap<K extends Comparable<? super K>, V extends Comparable<? super V>> {
    /**
     * Means the set is in the preparing stage, call put is valid and get is
     * invalid.
     */
    protected static final int STATUS_READY = 0;

    /**
     * Means the set is in the read-only stage after sorting, call put is
     * invalid and get is valid.
     */
    protected static final int STATUS_SORTED = 1;

    /**
     * The current status.
     */
    protected int status = STATUS_READY;
    
    /**
     * Construct a StaticSetMap in preparing stage.
     */
    public StaticSetMap() {
        reset();
    }
    
    /**
     * The List interface to access actual value.
     * 
     * @author David
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    protected static class ValueList<V> extends AbstractList<V> {
        private Object[] words;

        private int start;

        private int count = 0;

        private ValueList(Object[] words, int start) {
            this.words = words;
            this.start = start;
        }

        /**
         * @see AbstractList#get(int)
         */
        @SuppressWarnings("unchecked")
        @Override
        public V get(int index) {
            if (index < 0 || index >= count)
                throw new ArrayIndexOutOfBoundsException(index);
            return (V) words[index + start];
        }

        /**
         * @see List#size()
         */
        @Override
        public int size() {
            return count;
        }
    }
    
    /**
     * In STATUS_READY, keys/vals are used to hold unsorted keys/values
     */
    protected ArrayList<K> keys = new ArrayList<K>();

    /**
     * See above.
     */
    protected ArrayList<V> vals = new ArrayList<V>();

    /**
     * The List interface for access values in read-only stage.
     */
    protected ValueList<V>[] k2vList;

    /**
     * In STATUS_SORTED, keyList/valList are used to hold the sorted key array
     * and the corresponding value array.
     */
    protected Object[] keyList;

    /**
     * See above.
     */
    protected Object[] valList;
    /**
     * Associates the specified value with the specified key in this map
     * (optional operation).  If the map previously contained a mapping for
     * this key, the old value is replaced by the specified value.  (A map
     * <tt>m</tt> is said to contain a mapping for a key <tt>k</tt> if and only
     * if {@link #containsKey(Object) m.containsKey(k)} would return
     * <tt>true</tt>.)) 
     *
     * @param key key with which the specified value is to be associated.
     * @param val value to be associated with the specified key.
     * 
     * @throws UnsupportedOperationException if the <tt>put</tt> operation is
     *            not supported by this map.
     * @throws IllegalArgumentException if some aspect of this key or value
     *            prevents it from being stored in this map.
     * @throws NullPointerException if this map does not permit <tt>null</tt>
     *            keys or values, and the specified key or value is
     *            <tt>null</tt>.
     */
    public void put(K key, V val) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        keys.add(key);  vals.add(val);
    }
    /**
     * Puts all values to the map associating  with a key.
     * @param key  the key
     * @param valCol  the values
     */
    public void putAll(K key, Collection<V> valCol) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        keys.ensureCapacity(keys.size() + valCol.size());
        vals.ensureCapacity(vals.size() + valCol.size());
        for (V val: valCol) {
            keys.add(key);  vals.add(val);
        } // for v
    }
    /**
     * Puts all values to the map associating  with corresponding keys.
     * @param keyCol  the keys
     * @param valCol  the values
     */
    public void putAll(Collection<K> keyCol, Collection<V> valCol) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        int len = Math.min(keyCol.size(), valCol.size());
        keys.ensureCapacity(keys.size() + len);
        vals.ensureCapacity(vals.size() + len);
        Iterator<K> keyIter = keyCol.iterator();
        Iterator<V> valIter = valCol.iterator();
        for (int i = 0; i < len; i ++) {
            K key = keyIter.next();
            V val = valIter.next();
            keys.add(key);  vals.add(val);
        } // for i
    }
    /**
     * Puts all pairs to the map.
     * @param map  the pairs as a Map
     */
    public void putAll(Map<K, V> map) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        
        keys.ensureCapacity(keys.size() + map.size());
        vals.ensureCapacity(vals.size() + map.size());
        
        for (Map.Entry<K, V> ent: map.entrySet()) {
            keys.add(ent.getKey());  vals.add(ent.getValue());
        } // for ent
    }

    /**
     * Sorts the pairs. After calling this method, put() can not be called any
     * more unless this map is reset.
     */
    @SuppressWarnings("unchecked")
    public void sort() {
        int[] indexes = new int[keys.size()];
        for (int i = 0; i < keys.size(); i ++)
            indexes[i] = i;
        
        ArrayUtils.sort(indexes, new ArrayUtils.IIntComparator() {
            public int compare(int o1, int o2) {
                int res = keys.get(o1).compareTo(keys.get(o2));
                if (res != 0)
                    return res;
                
                return vals.get(o1).compareTo(vals.get(o2));
            }
        });
        
        int keyCount = 0;
        int valCount = 0;
        K lastKey = null;
        V lastVal = null;
        for (int i = 0; i < indexes.length; i ++) {
            int idx = indexes[i];
            K key = keys.get(idx);  V val = vals.get(idx);
            if (i > 0 && key.equals(lastKey)) {
                if (val.equals(lastVal))
                    /*
                     * Duplicated pairs, dicard
                     */
                    continue;
                valCount ++;
            } else {
                /*
                 * A new key (thus a new value)
                 */
                keyCount ++;
                lastKey = key;
                
                valCount ++;
            }
            
            lastVal = val;
        } // for i
        k2vList = new ValueList[keyCount];  keyList = new Object[keyCount];
        valList = new Object[valCount];
        
        keyCount = 0;
        valCount = 0;
        lastKey = null;
        lastVal = null;
        for (int i = 0; i < indexes.length; i ++) {
            int idx = indexes[i];
            K key = keys.get(idx);  V val = vals.get(idx);
            if (i > 0 && key.equals(lastKey)) {
                /*
                 * Same key as lastKey
                 */
                if (val.equals(lastVal))
                    /*
                     * Duplicated pairs, dicard
                     */
                    continue;
                /*
                 * New value under same key
                 */
                valList[valCount] = val;  k2vList[keyCount - 1].count ++;
                valCount ++;
            } else {
                /*
                 * A new key (thus a new value)
                 */
                keyList[keyCount] = key;
                k2vList[keyCount] = new ValueList<V>(valList, valCount);
                keyCount ++;
                lastKey = key;
                
                valList[valCount] = val;  k2vList[keyCount - 1].count ++;
                valCount ++;
            }
            
            lastVal = val;
        } // for i
        
        status = STATUS_SORTED;
        keys = null;  vals = null;
    }
    
    /**
     * Returns the number of key-value mappings in this map.  If the
     * map contains more than <tt>Integer.MAX_VALUE</tt> elements, returns
     * <tt>Integer.MAX_VALUE</tt>.
     *
     * @return the number of key-value mappings in this map.
     */
    public int size() {
        return keyList.length;
    }
    /**
     * Returns the number of values.
     * @return  the number of values.
     */
    public int valueSize() {
        return valList.length;
    }
    /**
     * Returns <tt>true</tt> if this map contains no key-value mappings.
     *
     * @return <tt>true</tt> if this map contains no key-value mappings.
     */
    public boolean isEmpty() {
        return size() == 0;
    }
    /**
     * Returns the value-list to which this map maps the specified key. Returns
     * <tt>null</tt> if the map contains no mapping for this key.
     * 
     * NOTE:
     *   the returned list is READ-ONLY.
     *
     * @param key  key whose associated value is to be returned.
     * @return  the value-list to which this map maps the specified key, or
     *         <tt>null</tt> if the map contains no mapping for this key.
     */
    public List<V> get(K key) {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        int idx = Arrays.binarySearch(keyList, key);
        if (idx < 0)
            return null;
        return k2vList[idx];
    }
    
    /**
     * Reset the status of this map.
     */
    void reset() {
        keys = new ArrayList<K>();
        vals = new ArrayList<V>();
        status = STATUS_READY;
    }
}
