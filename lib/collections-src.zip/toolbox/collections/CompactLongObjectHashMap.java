/**
 * @(#)CompactLongObjectHashMap.java, 2012-5-31. 
 * 
 * Copyright 2012 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections;

import java.util.NoSuchElementException;

import toolbox.collections.CompactLongLongHashMap;
import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * 修改自 {@link CompactLongLongHashMap}，使得 value 能支持其他数据
 * @author jiangfy
 *
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class CompactLongObjectHashMap<V> {
    private static final int MAX_CAPACITY = 1 << 30;
    private static final int DEFAULT_INITIAL_CAPACITY = 16;
    private static final float DEFAULT_LOAD_FACTOR = 2f;
    
    private static int CURR_EMPTY = 0;
    private static int NEXT_NULL = -1;
    
    private long[] keys;
    private Object[] vals;
    private int[] nexts;
    
    private int size;
    private int freeTop;
    private int minHeap;
    
    private float loadFactor;
    private int expandSize;
    
    /**
     * The constructor with default initial capacity and load-factor
     */
    public CompactLongObjectHashMap() {
        this(DEFAULT_INITIAL_CAPACITY, DEFAULT_LOAD_FACTOR);
    }
    
    /**
     * The constructor with specified initial capacity and default load-factor
     * 
     * @param capacity
     *            the intial capacity
     */
    public CompactLongObjectHashMap(int capacity) {
        this(capacity, DEFAULT_LOAD_FACTOR);
    }

    /**
     * The constructor with specified initial capacity and load-factor
     * 
     * @param capacity
     * @param loadFactor
     */    
    public CompactLongObjectHashMap(int capacity, float loadFactor) {
        int realSize = 1;
        while (realSize < capacity) {
            realSize = realSize << 1;
        } // while
        if (realSize > MAX_CAPACITY) 
            realSize = MAX_CAPACITY;
        
        keys = new long[realSize * 2];
        vals = new String[keys.length];
        nexts = new int[keys.length];
        freeTop = keys.length / 2;  
        minHeap = freeTop;
        expandSize = (int) (keys.length / 2.0f * loadFactor);
        size = 0;
        
        this.loadFactor = loadFactor;
    }
    
    private void resize(int capacity) {
        long[] newKeys = new long[capacity * 2];
        Object[] newVals = new Object[newKeys.length];
        int[] newNexts = new int[newKeys.length];
        int newFreeTop = capacity;
        
        int cnt = keys.length / 2;
        for (int i = 0; i < cnt; i ++) {
            if (nexts[i] != CURR_EMPTY) {
                int cur = i;
                while (cur != NEXT_NULL) {
                    int index = index(keys[cur], capacity);
                    
                    if (newNexts[index] == CURR_EMPTY) {
                        newKeys[index] = keys[cur];
                        newVals[index] = vals[cur];
                        newNexts[index] = NEXT_NULL;
                    } else {
                        newKeys[newFreeTop] = keys[cur];
                        newVals[newFreeTop] = vals[cur];
                        newNexts[newFreeTop] = newNexts[index];
                        
                        newNexts[index] = newFreeTop;
                        
                        newFreeTop ++;
                    } // else
                    
                    cur = nexts[cur];
                } // while
            }
        } // for entry

        keys = newKeys;  vals = newVals;
        nexts = newNexts;
        freeTop = newFreeTop;
        minHeap = newFreeTop;
        expandSize = (int) (keys.length / 2.0f * loadFactor);
    }
    
    /**
     * Calculate the index of a given long key. This code is migrated from 
     * jdk source.
     * @param key
     * @param size
     * @return
     */
    protected int index(long key, long size) {
        int h = (int) (key ^ (key >>> 32));
        h += ( h << 9);
        h ^= ( h >>> 14);
        h += ( h << 4);
        h ^= ( h >> 10);
        return (int)(h & (size-1));
    }

    /**                 
     * Returns <tt>true</tt> if this map contains a mapping for the specified
     * key.             
     *                  
     * @param key       
     *            key whose presence in this map is to be tested
     * @return <tt>true</tt> if this map contains a mapping for the specified
     *         key
     */    
    public boolean containsKey(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            return false;
        while (index != NEXT_NULL) {
            if (keys[index] == key)
                return true;
            
            index = nexts[index];
        } // while

        return false;
    }
    
    /**
     * Returns the value to which the specified key is mapped, or null if
     * this map contains no mapping for the key.
     */
    @SuppressWarnings("unchecked")
    public V get(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            return null;
        while (index != NEXT_NULL) {
            if (keys[index] == key)
                return (V) vals[index];
            
            index = nexts[index];
        } // while

        return null;
    }

    /**
     * Associates the specified val with the specified key in this map
     */
    public void put(long key, V val) {
        if ((size > expandSize || freeTop == keys.length) && 
                keys.length < MAX_CAPACITY) {
            resize(keys.length);
        } // if
        
        int head = index(key, keys.length / 2);
        if (nexts[head] == CURR_EMPTY) {
            /*
             * Head position is empty, put it here
             */
            keys[head] = key;  vals[head] = val;
            nexts[head] = NEXT_NULL;
            size ++;
            return;
        } // if
        int cur = head;
        while (cur != NEXT_NULL) {
            if (keys[cur] == key) {
                vals[cur] = val;
                return;
            } // if
            
            cur = nexts[cur];
        } // while
        /*
         * Not found, allocate a new position
         */
        int newIndex = freeTop;
        if (freeTop == minHeap) {
            freeTop ++;  minHeap ++;
        } else {
            freeTop = nexts[freeTop];
        } // else
        /*
         * Insert the key to the node following head
         *   before:
         *     tail = nexts[index];
         *     [index] -> [tail]
         *   after:
         *     [index] -> [newIndex] -> [tail] 
         */
        keys[newIndex] = key;  vals[newIndex] = val;
        nexts[newIndex] = nexts[head];
        nexts[head] = newIndex;
        /*
         * increase the size
         */
        size ++;
    }
    private void freeEntry(int index) {
        nexts[index] = freeTop;
        freeTop = index;
    }

    /**
     * Removes the mapping for a key from this map if it is present
     */
    public void remove(long key) {
        int index = index(key, keys.length / 2);
        if (nexts[index] == CURR_EMPTY)
            /*
             * No entries for this hash-index
             */
            return;
        
        int next = nexts[index];
        if (keys[index] == key) {
            /*
             * First entry is the one
             */
            if (next == NEXT_NULL) {
                /*
                 * Only one entry, simply set it to be empty
                 */
                nexts[index] = CURR_EMPTY;
            } else {
                /*
                 * Otherwise, copy <next> entry to head,
                 */
                keys[index] = keys[next];  vals[index] = vals[next];
                nexts[index] = nexts[next];
                /*
                 * and free <next> entry
                 */
                freeEntry(next);
            } // else

            size --;
            return;
        }
        /*
         * Try find the entry in non-head entries
         */
        while (next != NEXT_NULL) {
            if (keys[next] == key) {
                /*
                 * Found it, skip it and free it
                 */
                nexts[index] = nexts[next];
                freeEntry(next);
                size --;
                return;
            } // if
            
            index = next;
            next = nexts[index];
        } // while
    }
    
    /**
     * Return an iterator over all the mappings in this map.
     */
    public LongObjectHashMapIterator iterator() {
        return new LongObjectHashMapIterator();
    }
    
    /**
     * return  the number of key-value pairs in this map
     */
    public int size() {
        return size;
    }

    /**
     * return  whether the map is empty
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Remove all elements in this map.
     * NOTE: calling to this method does not change the capacity of this map
     *
     */
    public void clear() {
        for (int i = nexts.length / 2 - 1; i >= 0; i --)
            nexts[i] = CURR_EMPTY;
        
        freeTop = keys.length / 2;  minHeap = freeTop;
        size = 0;
    }

    /**
     * Return a string representation for all the mappings in this map.
     */    
    @Override
    public String toString() {
        StringBuilder str = new StringBuilder(size * (8*2 + 2));
        str.append("[");
        LongObjectHashMapIterator iter = iterator();
        boolean first = true;
        while (iter.hasNext()) {
            if (!first) {
                str.append(", ");
            } else {
                first = false;
            } // else
            iter.next();
            str.append(iter.getKey()).append("=").append(iter.getValue());
        } // while
        str.append("]");
        return "";
    }

    /**
     * The iterator class for CompactLongObjectHashMap.
     * 
     * Usage:
     *   LongObjectHashMapIterator iter = map.iterator();
     *   while (iter.hasNext()) {
     *       iter.next();
     *       
     *       iter.getKey();
     *       iter.getValue();
     *       
     *       iter.remove();
     *   } // while
     * 
     * @author david
     *
     */
    @InterfaceAudience.Public
    @InterfaceStability.Stable
    public class LongObjectHashMapIterator {
        private int index;  // current slot
        private int current, next;
        
        LongObjectHashMapIterator() {
            current = NEXT_NULL;
            
            int[] n = nexts;
            index = keys.length / 2 - 1;
            if (size != 0) {
                while (n[index] == CURR_EMPTY)
                    index --;
                next = index;
                index --;
            } else {
                next = NEXT_NULL;
            } // else
        }

        /**
         * Returns <tt>true</tt> if the iteration has more elements. (In other
         * words, returns <tt>true</tt> if <tt>next</tt> would return an element
         * rather than throwing an exception.)
         *
         * @return <tt>true</tt> if the iterator has more elements.
         */
        public boolean hasNext() {
            return next != NEXT_NULL;
        }
        
        /**
         * Moves the iterator to the next element in the iteration.  Calling this method
         * repeatedly until the {@link #hasNext()} method returns false will
         * return each element in the underlying collection exactly once.
         *
         * @exception NoSuchElementException iteration has no more elements.
         */
        public void next() {
            int c = next;
            if (c == NEXT_NULL)
                throw new NoSuchElementException();
            
            next = nexts[next];
            if (next <= 0) {
                while (index >= 0 && nexts[index] == CURR_EMPTY)
                    index --;
                if (index >= 0) {
                    next = index;
                    index --;
                } else {
                    next = NEXT_NULL;
                } // else
            } // if
            current = c;
        }

        /**
         * Returns the current key.
         * @return the current key
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called.
         */
        public long getKey() {
            if (current == NEXT_NULL)
                throw new IllegalStateException();
            return keys[current];
        }
        /**
         * Returns the current value.
         * 
         * @return the current value
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called.
         */
        @SuppressWarnings("unchecked")
        public V getValue() {
            if (current == NEXT_NULL)
                throw new IllegalStateException();
            
            return (V) vals[current];
        }

        /**
         * 
         * Removes from the underlying collection the last element returned by the
         * iterator (optional operation).  This method can be called only once per
         * call to <tt>next</tt>.  The behavior of an iterator is unspecified if
         * the underlying collection is modified while the iteration is in
         * progress in any way other than by calling this method.
         *
         * @exception IllegalStateException if the <tt>next</tt> method has not
         *            yet been called, or the <tt>remove</tt> method has already
         *            been called after the last call to the <tt>next</tt>
         *            method.
         */
        public void remove() {
            if (current == NEXT_NULL) 
                throw new IllegalStateException();

            if (current >= keys.length / 2) {
                /*
                 * current not in main-table, remove it will not change
                 * the value of this.next
                 */
                CompactLongObjectHashMap.this.remove(keys[current]);
            } else {
                int next = nexts[current];
                if (next == NEXT_NULL) {
                    nexts[current] = CURR_EMPTY;
                } else {
                    keys[current] = keys[next];
                    vals[current] = vals[next];
                    nexts[current] = nexts[next];
                    
                    freeEntry(next);
                    this.next = current;
                } // else
                size --;
            } // else
            
            current = NEXT_NULL;
        }
    }
}

