package toolbox.collections;

import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static set-map (the map from <key> -> set<value>, here the set is 
 * represented as a list without duplicated values).
 * 
 * This class is mainly used to providing a static look-up-table. It is memory
 * efficiency compared with HashMap<K, ArrayList<V>>();
 * 
 * Usage:
 *   StaticMap<K, V> map = new StaticMap<K, V>();
 *   
 *   map.put(key, value);
 *   map.putAll(...);
 *   ...
 *   // Calling to map.get(...) here is illegal and will cause an exception.
 *   
 *   map.sort();
 *   // use map as a normal map with read-only actions   
 *   V value = map.get(key); ...
 *   // Calling to map.put(...) here is illegal and will cause an exception.
 *   
 * Implementaion:
 *   Key-value pairs are stored in an array-list. In sort() method, the list
 *   is sorted. A binary-search is performed for searching values on the sorted
 *   list.
 *   
 * @author david
 *
 * @param <K>  the key type
 * @param <V>  the value type
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class StaticMap<K extends Comparable<? super K>, V> implements Map<K,V> {
    /**
     * Means the set is in the preparing stage, call put is valid and get is
     * invalid.
     */
    protected static final int STATUS_READY = 0;

    /**
     * Means the set is in the read-only stage after sorting, call put is
     * invalid and get is valid.
     */
    protected static final int STATUS_SORTED = 1;

    /**
     * The current status.
     */
    protected int status = STATUS_READY;
    
    /**
     * The constructor.
     */
    public StaticMap() {
        reset();
    }

    /**
     * In STATUS_READY, keys/vals are used to hold unsorted keys/values
     */
    protected ArrayList<K> keys = new ArrayList<K>();

    /**
     * see above.
     */
    protected ArrayList<V> vals = new ArrayList<V>();

    /**
     * In STATUS_SORTED, keyList/valList are used to hold the sorted key array
     * and the corresponding value array.
     */
    protected Object[] keyList;

    /**
     * see above.
     */
    protected Object[] valList;
    /**
     * Associates the specified value with the specified key in this map
     * (optional operation).  If the map previously contained a mapping for
     * this key, either old value or the specified value will be lost.  (A map
     * <tt>m</tt> is said to contain a mapping for a key <tt>k</tt> if and only
     * if {@link #containsKey(Object) m.containsKey(k)} would return
     * <tt>true</tt>.)) 
     *
     * @param key key with which the specified value is to be associated.
     * @param val value to be associated with the specified key.
     * @return null.
     * 
     * @throws UnsupportedOperationException if the map has been sorted.
     */
    public V put(K key, V val) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        keys.add(key);  vals.add(val);
        return null;        
    }
    
    /**
     * Puts all values to the map associating with corresponding keys.
     * 
     * @param keyCol  the keys
     * @param valCol  the values
     * @throws UnsupportedOperationException if the map has been sorted.
     */
    public void putAll(Collection<K> keyCol, Collection<V> valCol) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        
        int len = Math.min(keyCol.size(), valCol.size());
        keys.ensureCapacity(keys.size() + len);
        vals.ensureCapacity(vals.size() + len);
        Iterator<K> keyIter = keyCol.iterator();
        Iterator<V> valIter = valCol.iterator();
        for (int i = 0; i < len; i ++) {
            K key = keyIter.next();
            V val = valIter.next();
            keys.add(key);  vals.add(val);
        } // for i
    }
    
    /**
     * Puts all pairs to the map.
     * @param map  the pairs as a Map
     * @throws UnsupportedOperationException if the map has been sorted.
     */
    public void putAll(Map<? extends K, ? extends V> map) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        
        keys.ensureCapacity(keys.size() + map.size());
        vals.ensureCapacity(vals.size() + map.size());
        
        for (Map.Entry<? extends K, ? extends V> ent: map.entrySet()) {
            keys.add(ent.getKey());  vals.add(ent.getValue());
        } // for ent
    }

    /**
     * Switches the status from ready to sorted
     */
    protected void switchToSorted() {
        status = STATUS_SORTED;
        keys = null;  vals = null;
    }

    /**
     * Sorts the pairs. After calling this method, put() can not be called any
     * more unless this map is reset.
     */
    public void sort() {
        /*
         * Sort by keys
         */
        int[] indexes = new int[keys.size()];
        for (int i = 0; i < keys.size(); i ++)
            indexes[i] = i;
        
        ArrayUtils.sort(indexes, new ArrayUtils.IIntComparator() {
            public int compare(int o1, int o2) {
                return keys.get(o1).compareTo(keys.get(o2));
            }
        });
        /*
         * Count the number of unique keys
         */
        int keyCount = 0;
        K lastKey = null;
        for (int i = 0; i < indexes.length; i ++) {
            int idx = indexes[i];
            K key = keys.get(idx);
            if (i == 0 || !key.equals(lastKey)) {
                /*
                 * A new key (thus a new value)
                 */
                keyCount ++;
                lastKey = key;
            }
        } // for i
        keyList = new Object[keyCount];
        valList = new Object[keyCount];
        /*
         * Store key/values in two arrays
         */
        keyCount = 0;
        lastKey = null;
        for (int i = 0; i < indexes.length; i ++) {
            int idx = indexes[i];
            K key = keys.get(idx);  V val = vals.get(idx);
            if (i == 0 || !key.equals(lastKey)) {
                /*
                 * A new key (thus a new value)
                 */
                keyList[keyCount] = key;
                valList[keyCount] = val;
                keyCount ++;
                lastKey = key;
                
            }
        } // for i
        /*
         * Now switch to sorted status
         */
        switchToSorted();
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int size() {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        
        return keyList.length;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    public V get(Object key) {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        int idx = Arrays.binarySearch(keyList, key);
        if (idx < 0)
            return null;
        return (V) valList[idx];
    }
    
    /**
     * Resets the status of this map.
     */
    public void reset() {
        keys = new ArrayList<K>();
        vals = new ArrayList<V>();
        
        keyList = null;  valList = null;
        status = STATUS_READY;
    }
    
    /**
     * Call {@link #reset()} instead.
     */
    @Override
    public void clear() {
        throw new UnsupportedOperationException(
                "Call reset() to reset the entries.");
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean containsKey(Object key) {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        int idx = Arrays.binarySearch(keyList, key);
        return idx >= 0;
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public boolean containsValue(Object value) {
        throw new UnsupportedOperationException("Cannot search for value!");
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");

        return new AbstractSet<Map.Entry<K, V>>() {
            Object[] keys = StaticMap.this.keyList;
            Object[] vals = StaticMap.this.valList;
            
            @Override
            public Iterator<Map.Entry<K, V>> iterator() {
                return new Iterator<java.util.Map.Entry<K, V>>() {
                    int index = 0;
                    
                    @Override
                    public boolean hasNext() {
                        return index < keys.length;
                    }

                    @SuppressWarnings("unchecked")
                    @Override
                    public Entry<K, V> next() {
                        Map.Entry<K, V> entry = new Map.Entry<K, V>() {
                            K key = (K) keys[index];
                            V val = (V) vals[index];
                            
                            @Override
                            public K getKey() {
                                return key;
                            }

                            @Override
                            public V getValue() {
                                return val;
                            }

                            @Override
                            public V setValue(V value) {
                                throw new UnsupportedOperationException();
                            }

                            @Override
                            public int hashCode() {
                                return (key == null ? 0 : key.hashCode())
                                        ^ (val == null ? 0 : val.hashCode());
                            }

                            @SuppressWarnings("rawtypes")
                            @Override
                            public boolean equals(Object obj) {
                                if (!(obj instanceof Map.Entry))
                                    return false;
                                Map.Entry e = (Map.Entry) obj;
                                Object k1 = getKey();
                                Object k2 = e.getKey();
                                if (k1 == k2 || (k1 != null && k1.equals(k2))) {
                                    Object v1 = getValue();
                                    Object v2 = e.getValue();
                                    if (v1 == v2
                                            || (v1 != null && v1.equals(v2)))
                                        return true;
                                }
                                return false;
                            }
                            
                            
                        };
                        
                        index ++;
                        
                        return entry;
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }

            @SuppressWarnings("rawtypes")
            @Override
            public boolean contains(Object o) {
                int idx = Arrays.binarySearch(keys, ((Map.Entry) o).getKey());
                if (idx < 0)
                    return false;
                
                return ((Map.Entry) o).getValue().equals(vals[idx]);
            }
            
            @Override
            public int size() {
                return keys.length;
            }
        };
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<K> keySet() {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        
        return new AbstractSet<K>() {
            Object[] list = StaticMap.this.keyList;
            
            @Override
            public boolean contains(Object o) {
                return Arrays.binarySearch(list, o) >= 0;
            }
            
            @Override
            public Iterator<K> iterator() {
                return new Iterator<K>() {
                    int index = 0;
                    
                    @Override
                    public boolean hasNext() {
                        return index < list.length;
                    }

                    @SuppressWarnings("unchecked")
                    @Override
                    public K next() {
                        return (K) list[index ++];
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }

            @Override
            public int size() {
                return list.length;
            }
        };
    }

    /**
     * Not implemented.
     */
    @Override
    public V remove(Object key) {
        throw new UnsupportedOperationException("Deletion is not supported. " 
                + "Call reset to remove all entries.");
    }
    
    /**
     * {@inheritDoc}
     */
    @Override
    public Collection<V> values() {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        
        return new AbstractCollection<V>() {
            Object[] list = StaticMap.this.valList;
            
            @Override
            public Iterator<V> iterator() {
                return new Iterator<V>() {
                    int index = 0;
                    
                    @Override
                    public boolean hasNext() {
                        return index < list.length;
                    }

                    @SuppressWarnings("unchecked")
                    @Override
                    public V next() {
                        if (!hasNext()) {
                            throw new NoSuchElementException();
                        }
                        return (V) list[index ++];
                    }

                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }

            @Override
            public int size() {
                return list.length;
            }
        };
    }
    
    
    /**
     * {@inheritDoc}
     */
    @Override
    public int hashCode() {
        int h = 0;
        Iterator<Entry<K, V>> iter = entrySet().iterator();
        while (iter.hasNext()) {
            h += iter.next().hashCode();
        }
        return h;
    }

    /**
     * Return <code>true</code> iff all the mappings are equal.
     */
    @SuppressWarnings("unchecked")
    @Override
    public boolean equals(Object o) {
        if (o == this)
            return true;

        if (!(o instanceof Map))
            return false;
        Map<K,V> t = (Map<K,V>) o;
        if (t.size() != size())
            return false;

        try {
            Iterator<Entry<K,V>> i = entrySet().iterator();
            while (i.hasNext()) {
                Entry<K,V> e = i.next();
                K key = e.getKey();
                V value = e.getValue();
                if (value == null) {
                    if (!(t.get(key)==null && t.containsKey(key)))
                        return false;
                } else {
                    if (!value.equals(t.get(key)))
                        return false;
                }
            }
        } catch(ClassCastException unused) {
            return false;
        } catch(NullPointerException unused) {
            return false;
        }

        return true;
    }
}
