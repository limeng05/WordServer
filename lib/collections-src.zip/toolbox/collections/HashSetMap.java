package toolbox.collections;

import java.util.HashSet;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A map whose value is a HashSet.
 * 
 * @author david
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HashSetMap<K, V> extends HashCollectionMap<K, V, HashSet<V>> {
    private static final long serialVersionUID = -6955924494985752255L;

    /**
     * Default constructor.
     */
    @SuppressWarnings({
        "rawtypes", "unchecked"
    })
    public HashSetMap() {
        super((Class) HashSet.class);
    }

}
