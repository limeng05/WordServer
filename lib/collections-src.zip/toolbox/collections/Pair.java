/**
 * @(#)Pair.java, 2008-7-30. 
 * 
 * Copyright 2008 Yodao, Inc. All rights reserved.
 * YODAO PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
package toolbox.collections;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * Container to hold two objects. The first and second fields can hold null
 * value. This class do deep compare in method {@link #equals(Object)}, that is
 * to say, the fields value should be compared, and the pairs hold same
 * value(for example, different string objects of same content) should be
 * regarded as same.
 * 
 * @author river
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class Pair<V1, V2> {
    private static final int NULL_HASH = "NULL".hashCode();

    /**
     * The first part.
     */
    protected V1 first;

    /**
     * The second part.
     */
    protected V2 second;

    /**
     * Create empty pair.
     */
    public Pair() {}

    /**
     * Create pair with initial values.
     * 
     * @param first
     * @param second
     */
    public Pair(V1 first, V2 second) {
        this.first = first;
        this.second = second;
    }

    /**
     * Return the first value.
     * 
     * @return
     */
    public V1 getFirst() {
        return first;
    }

    /**
     * Set the first value.
     * 
     * @param v
     */
    public void setFirst(V1 v) {
        this.first = v;
    }

    /**
     * Return the second value.
     * 
     * @return
     */
    public V2 getSecond() {
        return second;
    }

    /**
     * Set the second value.
     * 
     * @param v
     */
    public void setSecond(V2 v) {
        this.second = v;
    }

    /**
     * @see Object#hashCode()
     */
    @Override
    public int hashCode() {
        return (first == null ? NULL_HASH : first.hashCode())
                ^ (second == null ? NULL_HASH : second.hashCode());
    }

    /**
     * Return <code>true</code> iff the two parts are both equal.
     */
    @SuppressWarnings("rawtypes")
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }

        Pair that = (Pair) o;
        return ((this.first == null && that.first == null) || (this.first != null && this.first.equals(that.first)))
                && ((this.second == null && that.second == null) || (this.second != null && this.second.equals(that.second)));
    }

    /**
     * Return a string representation.
     */
    @Override
    public String toString() {
        return "<" + first + ", " + second + ">";
    }

}
