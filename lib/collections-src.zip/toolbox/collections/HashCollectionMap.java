package toolbox.collections;

import java.util.Collection;
import java.util.HashMap;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A map whose value is a collection. The class implements some append and
 * appendUniq methods which creates the element collection instance when
 * necessary.
 * 
 * Example:
 *   HashCollectionMap<String, Integer, ArrayList<Integer>> types =
 *      new HashCollectionMap<String, Integer, ArrayList<Integer>>(
 *              ArrayList<Integer>.class);
 *   
 *   types.append("hello", 1);
 *   types.append("hello", 3);
 *   
 *   types.appendUniq("hello", 2);
 *   types.appendUniq("hello", 3);
 *   
 *   /// now types.get("hello") is an array-list of [1, 3, 2].
 * 
 * @author david
 *
 * @param <K>  the type of key
 * @param <V>  the type of the element of the collection
 * @param <CV>  the type of the collection of the value
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class HashCollectionMap<K, V, CV extends Collection<V>> 
    extends HashMap<K, CV> {
    private static final long serialVersionUID = -262782140089848289L;
    private Class<CV> collectionClass;
    /**
     * Constructor.
     * @param collectionClass  the class of the collection element.
     */
    public HashCollectionMap(Class<CV> collectionClass) {
        this.collectionClass = collectionClass;
    }
    
    /**
     * Constructor a collection instance.
     */
    protected CV newCollection() {
        try {
            return collectionClass.newInstance();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    /**
     * Appends a value to the list of a specified key. If the list does not
     * exists, creates one.
     * @param key  the key
     * @param val  the value to be appended
     */
    public void append(K key, V val) {
        CV list = get(key);
        if (list == null) {
            list = newCollection();
            put(key, list);
        } // if
        
        list.add(val);
    }
    /**
     * Appends some values to the list of a specified key. If the list does not
     * exists, creates one.
     * @param key  the key
     * @param vals  the values to be appended
     */
    public void append(K key, V[] vals) {
        CV list = get(key);
        if (list == null) {
            list = newCollection();
            put(key, list);
        } // if
        
        for (V val: vals)
            list.add(val);
    }
    /**
     * Appends some values to the list of a specified key. If the list does not
     * exists, creates one.
     * @param key  the key
     * @param vals  the values to be appended
     */
    public void append(K key, Collection<V> vals) {
        CV list = get(key);
        if (list == null) {
            list = newCollection();
            put(key, list);
        } // if
        
        list.addAll(vals);
    }
    /**
     * Appends a value to the list of a specified key if the value was not
     * contained in the previous list. If the list does not exists, creates one.
     * @param key  the key
     * @param val  the values to be appended
     */
    public void appendUniq(K key, V val) {
        CV list = get(key);
        if (list == null) {
            list = newCollection();
            put(key, list);
        } // if

        if (!list.contains(val))
            list.add(val);
    }
    /**
     * Appends some values to the list of a specified key if the value was not
     * contained in the previous list. If the list does not exists, creates one.
     * @param key  the key
     * @param vals  the values to be appended
     */
    public void appendUniq(K key, V[] vals) {
        CV list = get(key);
        if (list == null) {
            list = newCollection();
            put(key, list);
        } // if
        
        for (V val: vals)
            if (!list.contains(val))
                list.add(val);
    }
}
