package toolbox.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Set;

import toolbox.tbv.common.InterfaceAudience;
import toolbox.tbv.common.InterfaceStability;

/**
 * A static sorted set.
 * 
 * This class is mainly used to providing a static(read-only) set. It is memory
 * efficiency compared with HashSet<K>;
 * 
 * Usage:
 *   StaticSet<K> set = new StaticSet<K>();
 *   
 *   set.add(key);
 *   ...
 *   // Calling to set.contains(...) here is illegal and will cause an 
 *   // exception.
 *   
 *   set.sort();
 *   
 *   boolean res = set.contains(key); ...
 *   // Calling to set.add(...) here is illegal and will cause an exception.
 *   
 * Implementaion:
 *   Keys are stored in an array-list. In sort() method, the list is sorted. A 
 *   binary-search is performed for searching values on the sorted list.
 *   
 * @author david
 *
 * @param <K>  the type of keys
 */
@InterfaceAudience.Public
@InterfaceStability.Stable
public class StaticSet<K extends Comparable<? super K>> {
    private static final int STATUS_READY = 0;

    private static final int STATUS_SORTED = 1;

    private int status = STATUS_READY;
    
    /**
     * Construct a StaticSet in preparing stage.
     */
    public StaticSet() {
        reset();
    }
    
    private ArrayList<K> keys = new ArrayList<K>();
    
    private Object[] keyList;
    /**
     * Adds a new key to the set. 
     *
     * @param key  the new key instance
     * @throws UnsupportedOperationException  if the set has been sorted.
     */
    public void add(K key) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        keys.add(key);
    }
    /**
     * Adds all elements of a set to the set.
     * @param newKeys  the set of new keys
     * @throws UnsupportedOperationException  if the set has been sorted.
     */
    public void addAll(Set<K> newKeys) {
        if (status != STATUS_READY)
            throw new UnsupportedOperationException("Can not put new " +
                        "key-values after sorting!");
        
        keys.ensureCapacity(keys.size() + newKeys.size());
        
        for (K newKey: newKeys) {
            keys.add(newKey);
        } // for ent
    }

    /**
     * Sorts the pairs. After calling this method, add()/addAll() can not be 
     * called unless this set is reset().
     */
    public void sort() {
        Collections.sort(keys);
        int keyCount = 0;
        K lastKey = null;
        for (int i = 0; i < keys.size(); i ++) {
            K key = keys.get(i);
            if (i == 0 || !key.equals(lastKey)) {
                /*
                 * A new key
                 */
                keyCount ++;
                lastKey = key;
            } // if
        } // for i
        keyList = new Object[keyCount];
        
        keyCount = 0;
        lastKey = null;
        for (int i = 0; i < keys.size(); i ++) {
            K key = keys.get(i);
            if (i == 0 || !key.equals(lastKey)) {
                /*
                 * A new key
                 */
                keyList[keyCount] = key;
                keyCount ++;
                lastKey = key;
            } // if
        } // for i
        
        status = STATUS_SORTED;
        keys = null;
    }
    
    /**
     * Returns the number of keys in this set.
     *
     * @return the number of keys in this set.
     */
    public int size() {
        return keyList.length;
    }
    /**
     * Returns <tt>true</tt> if this set contains no keys.
     *
     * @return <tt>true</tt> if this set contains no keys.
     */
    public boolean isEmpty() {
        return size() == 0;
    }
    /**
     * Returns <tt>true</tt> if this set contains the specified element.  More
     * formally, returns <tt>true</tt> if and only if this set contains an
     * element <code>e</code> such that <code>(o==null ? e==null :
     * o.equals(e))</code>.
     * 
     * @param key  element whose presence in this set is to be tested.
     * @return <tt>true</tt> if this set contains the specified element.
     * @throws UnsupportedOperationException  if the set has not been sorted.
     */
    public boolean contains(K key) {
        if (status != STATUS_SORTED)
            throw new UnsupportedOperationException("Call sort() before " +
                    "searching for the key!");
        return Arrays.binarySearch(keyList, key) >= 0;
    }
    
    /**
     * Resets the status of this map.
     */
    public void reset() {
        keys = new ArrayList<K>();
        status = STATUS_READY;
    }
}
